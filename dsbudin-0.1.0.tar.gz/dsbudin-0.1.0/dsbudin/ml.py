import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.pipeline import Pipeline
from sklearn.compose import make_column_selector
from sklearn.preprocessing import OrdinalEncoder
from sklearn.inspection import permutation_importance
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import GridSearchCV

# Машинное обучение:
#=====================================================================================================================

# выделение целевого признака:
def xy_split(data, target_column):
    return data.drop(columns=[target_column], axis=1), data[target_column]

# разбивка на валидационную и тестовую выборки (с отображением соотношения)
def research_test_split(df, test_size=0.2, random_state=12345):
    df_research, df_test = train_test_split(df, test_size=test_size, random_state=random_state)
    print()
    display(pd.DataFrame({
        'Выборка:': ['Исследовательская', 'Тестовая'],
        'Количество значений:': [df_research.shape[0], df_test.shape[0]],
        'Доля выборки:': [df_research.shape[0] / df.shape[0], df_test.shape[0] / df.shape[0]]
            }).style.format({'Количество значений': '{:.0f}', 'Доля выборки:': '{:.2%}'})
         )
    return df_research, df_test

# переименование параметров пайплайна
def rename_pipeline_params(params_pipeline):
    result = {}
    for p, val in params_pipeline.items():
        param = p.split('__')[1]
        result[param] = val
    return result

#--------------------------------------------------------------------------------------------------------------------------------------------

# Кросс-валидация с результатом для одной модели
def cross_val_base(model_name, model, X, y, scoring, print_res=True):
    time_start = time.time()
    scores = cross_val_score(model, X, y, scoring=scoring, cv=10)
    if print_res:
        print(f'Среднее значение метрики {scoring} для базовой модели {text.BOLD}{model_name}:\n{text.BG_SILVER} {scoring} = {scores.mean():.2f} {text.END}')
        print('-'*TABLE_SIZE)
        return
    return (model_name, scores.mean(), time.time() - time_start)

# вывод таблицы сравнения
def get_selection_model_results(results, score_name = 'Score'):
    res = pd.DataFrame(results, columns = ['Model', score_name, 'Time']).sort_values(by=score_name, ascending=False)
    
    res['rating_score'] = res.apply(
        lambda row: round((row[score_name] - res[score_name].min()) / (res[score_name].max() - res[score_name].min()), 3)
        , axis=1)
    res['rating_time'] = res.apply(
        lambda row: round(-(row['Time'] - res['Time'].min()) / (res['Time'].max() - res['Time'].min()), 3)
        , axis=1)
    res['rating_total'] = res['rating_score'] + res['rating_time']
    
    return res

#--------------------------------------------------------------------------------------------------------------------------------------------

# прямое кодирование
def get_research_test_m_ohe(df, features):
    df_major = make_df_major(df, features)
    df_major_ohe = pd.get_dummies(df_major, drop_first=True)
    
    # возвращаем df_research, df_test
    return research_test_split(df_major_ohe)

# поярдковое кодирование
# на вход подается pandas.DataFrame с признаками которые нужно кодировать типа 'category'
def get_research_test_m_oe(df, features):
    df_major = make_df_major(df, features)
    
    # через ColumnTransformer получается array без подписей с перемешанными колонками, поэтому так удобнее:
    encoder = OrdinalEncoder()
    df_major_oe = df_major.copy().reset_index(drop=True)
    df_major_oe[make_column_selector(dtype_include='category')] = encoder.fit_transform(df_major[make_column_selector(dtype_include='category')])
    
    # возвращаем df_research, df_test
    return research_test_split(df_major_oe)



# Оценка важности признаков
def get_important_columns(model, X, y, scoring, n_repeats=30, random_state=12345):
    model.fit(X, y)
    r = permutation_importance(model, X, y,
                               scoring = scoring,
                               n_repeats=n_repeats,
                               random_state=random_state)
    for i in r.importances_mean.argsort()[::-1]:
        if r.importances_mean[i] - 2 * r.importances_std[i] > 0:
            print(f"{X.columns[i]:<40}"
                  f"{r.importances_mean[i]:.6f}"
                  f" +/- {r.importances_std[i]:.6f}")
    return X.columns[r.importances_mean.argsort()[::-1]]

#--------------------------------------------------------------------------------------------------------------------------------------------

# Предсказания:
def print_predictions_type1(pred, y):
    plt.figure(figsize=(8, 8))
    plt.grid(visible=True, axis='both')
    limits = [min(y.min(), pred.min()), max(y.max()*1.05, pred.max()*1.05)]
    plt.xlim(limits)
    plt.ylim(limits)
    plt.plot(y, pred, 'x', alpha=0.6)
    plt.plot([limits[0], limits[1]], [limits[0], limits[1]], linewidth=3, color = 'firebrick')
    plt.title('Соотношение значений предсказаний и истинных значений\nна тестовой выборке', pad=15, fontsize = 15)
    plt.xlabel("Истинные значения", fontsize = 14)
    plt.ylabel("Значения предсказаний", fontsize = 14)
    plt.plot()

def print_predictions_type2(pred, y):
    plt.figure(figsize=(8, 8))
    plt.grid(visible=True, axis='both')
    plt.plot(y, pred-y, 'x', alpha=0.6)
    plt.plot(np.zeros(y.max()), linewidth=3, color = 'firebrick')
    plt.title('Отклонения значений предсказаний от истинных значений\nна тестовой выборке', pad=15, fontsize = 15)
    plt.xlabel("Истинные значения", fontsize = 14)
    plt.ylabel("Отклонения предсказаний", fontsize = 14)
    plt.plot()

# вывод итоговых метрик
def get_metrics(model, train_XY:tuple, test_XY:tuple):
    metrics = []

    probabilities_train = model.predict_proba(train_XY[0])[:, 1]
    probabilities_test = model.predict_proba(test_XY[0])[:, 1]
    
    predictions_train = model.predict(train_XY[0])
    predictions_test = model.predict(test_XY[0])

    metrics.append(['roc_auc', roc_auc_score(train_XY[1], probabilities_train), roc_auc_score(test_XY[1], probabilities_test)])
    metrics.append(['f1', f1_score(train_XY[1], predictions_train), f1_score(test_XY[1], predictions_test)])
    metrics.append(['accuracy', accuracy_score(train_XY[1], predictions_train), accuracy_score(test_XY[1], predictions_test)])
    
    return pd.DataFrame(metrics, columns = ['Метрика', 'Обучающая', 'Тестовая']).set_index('Метрика')

# вывод итоговых метрик
def get_metrics_ensemble(proda_train, proba_test, Y_train, Y_test):
    metrics = []
    
    predictions_train = proda_train > 0.5
    predictions_test = proba_test > 0.5

    metrics.append(['roc_auc', roc_auc_score(Y_train, proda_train), roc_auc_score(Y_test, proba_test)])
    metrics.append(['f1', f1_score(Y_train, predictions_train), f1_score(Y_test, predictions_test)])
    metrics.append(['accuracy', accuracy_score(Y_train, predictions_train), accuracy_score(Y_test, predictions_test)])
    
    return pd.DataFrame(metrics, columns = ['Метрика', 'Обучающая', 'Тестовая']).set_index('Метрика')

#--------------------------------------------------------------------------------------------------------------------------------------------


# Отрисовка кривой roc_auc
def print_roc_curve(model, features, target, subtitle='', figsize=(7, 7)):
    probabilities_test = model.predict_proba(features)
    probabilities_one_test = probabilities_test[:, 1]
    roc_auc = roc_auc_score(target, probabilities_one_test)
    
    fpr, tpr, thresholds = roc_curve(target, probabilities_one_test) 

    plt.figure(figsize=(figsize[0], figsize[1]))
    plt.plot(fpr, tpr, linewidth=3, color = 'darkcyan')
    plt.fill_between(fpr, tpr, 0, color = 'darkcyan', alpha=0.15)

    # ROC-кривая случайной модели (выглядит как прямая)
    plt.plot([0, 1], [0, 1], linestyle='--', color = 'darkkhaki')

    plt.xlim([-0.015, 1.0])
    plt.ylim([0.0, 1.015])
    plt.xlabel("False Positive Rate", fontsize = 14)
    plt.ylabel("True Positive Rate", fontsize = 14)
    plt.title(f"ROC-кривая{subtitle}", pad=15, fontsize = 16)
    
    plt.text(0.4, 0.1, f'Метрика roc_auc:\n{roc_auc:.4f}',
                rotation = 0,
                fontsize = min(figsize)*1.8,
                bbox = {'facecolor':'white', 'boxstyle': 'round', 'pad': min(figsize)/12}
                    )
    plt.show()


#gscv.cv_results_
def grid_search_cv(X, y, model, parameters, scoring=None, cv=5, plot=False):
    verbose = (0, 3)[plot]
    gscv = GridSearchCV(model, parameters, scoring=scoring, cv=cv, n_jobs=-1, verbose=verbose)
    gscv.fit(X, y)
    results = {
        'iterations': len(gscv.cv_results_['params']),
        'score': gscv.best_score_,
        'parameters': gscv.best_params_
    }
    return results


# Рабочая версия с обработкой Pipeline
# Проходит не по всей сетке, а пока растет значение метрики (Бейесовская оптимизация).
# Если метрика не растет на протажении хвоста (max_tail) цикл заканчивается
# На вход подается Класс модели, исследуемые гиперапараметры в виде словаря
# Работает быстрее, чем GridSearchCV
def ascending_grid(df_features, df_target, func, parameters, scoring=None, plot=False, subtitle='', max_tail=None, cv=5, n_jobs=-1, random_state=12345, **kwargs):
    #cv = 5 #при значении 5 результаты отличаются от результатов при значении > 10 ! но по умолчанию в cross_val_score стоит 5, поэтому оставим по умоланию 5
    steps = 100
    iterator = 0
    best_score = -1_000_000
    best_param = parameters
    tail = 0
    if max_tail == None:
        max_tail = 1 if 5 - len(parameters) < 1 else 5 - len(parameters)
    
    param = list(parameters.keys())[0]
    start = parameters[param][0]
    sep = parameters[param][1]
    
    if len(parameters) == 1:
        for p in np.arange(start, start+steps*sep, sep):
            set_param = {param: p}
            if type(func) == Pipeline:
                model = func
                model_name = model.get_params().get("steps")[-1][0]
                # Гиперпараметры (стандартные random_state=123, n_jobs=n_jobs задаются извне):
                # Текущая настройка
                model.set_params(**{model_name+'__'+param: p})
                # **kwargs
                params_temp = {}
                for key, val in kwargs.items():
                    params_temp[model_name+'__'+key] = val
                model.set_params(**params_temp)
            else:
                model = func(random_state=random_state, n_jobs=n_jobs, **set_param, **kwargs)
            scores = cross_val_score(model, df_features, df_target, scoring=scoring, cv=cv)
            score = scores.mean()
            iterator += len(scores)
            if plot:
                print(f'{p} >>> {set_param} {kwargs} - {score:.4f}')

            if score > best_score:
                best_score = score
                set_param.update(kwargs)
                best_param = set_param
                tail = 0
            else:
                tail += 1
            if tail >= max_tail:
                break
    else:
        # рекурсия
        parameters_minus = parameters.copy()
        del parameters_minus[param]
        for p in np.arange(start, start+steps*sep, sep):
            set_param = {param: p}
            result = ascending_grid(df_features, df_target, func, parameters_minus,
                                    scoring=scoring, plot=plot, subtitle=subtitle, max_tail=max_tail, cv=cv,
                                    **set_param, **kwargs)
            iterator += result['iterations']
            score = result['score']
            
            # Сокращение нижней границы поиска (предыдущее лучшее минус 2 промежутка)
            for key in result['parameters'].keys():
                try:
                    new_start = result['parameters'][key] - parameters_minus[key][1]*2
                    if parameters_minus[key][0] < new_start:
                        parameters_minus[key][0] = result['parameters'][key] - parameters_minus[key][1] * (max_tail + 1)
                except:
                    pass
            
            if score > best_score:
                best_score = score
                best_param = result['parameters']
                tail = 0
            else:
                tail += 1
            if tail >= max_tail:
                break
        
        if plot:
            print('best_score =', best_score)
            print('best_param =', best_param)
    if plot:
        print('-'*TABLE_SIZE)
    return ({'iterations': iterator, 'score':best_score, 'parameters':best_param})