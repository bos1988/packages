import pandas as pd
import numpy as np
from scipy import stats as st
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

#=====================================================================================================================
# Обработка:

# перевод из верблюжъего в змеиный регистр
def camel_to_snake(string, sep='_'):
    camel = ''
    for i in range(len(string)):
        camel += sep if string[i].isupper() and string[i-1].islower() else ''
        camel += string[i].lower()
    return camel.lstrip(sep)

# перевод из верблюжъего в змеиный регистр для словаря описания данных
def description_camel_to_snake(description_dict):
    camel_description = dict()
    for key, val in description_dict.items():
        camel_description[camel_to_snake(key)] = val
    return camel_description
 
 # Преобразование признаков к типу данных category
def set_category_type(df, cat_features):
    df_cat = df.copy()
    df_cat[cat_features] = df_cat[cat_features].astype('category')
    return df_cat

# вывод больших чисел
def big_number(val):
    dec = str(round(val * 100 % 100))
    s = list(str(round(val)).lstrip('-'))
    for i in range(0, len(s)-1, 4):
        s.insert(-i-3, '`')
    return ('','-')[int(val < 0)] + ''.join(s) + '.' + dec

# корреляция с целевым признаком
def get_corr(data, target):
    corrs = []
    for name in data.columns:
        corrs.append(data[name].corr(target))
    return pd.DataFrame({'name': data.columns, 'corr': corrs})

#=====================================================================================================================
# Информирование:

# вывод таблицы описания данных
def print_description(df):
    len_index = max([len(i) for i in df])
    for ind, name in enumerate(df):
        end = '' if len(description[name]) < TABLE_SIZE else '...'
        print(f'{str(ind).ljust(3)} {name.ljust(len_index)} - {description[name][:TABLE_SIZE]}{end}')

# общая информация об исходной таблице
def start_information(df):
    result = []
    for col in df:
        result.append([
            col, df[col].count(), df[col].isna().sum(),
            df[col].dtype, df[col].nunique(), df[col].sample(10).values,
        ])
        if str(df[col].dtype)[:3] in ('intflo'):
            result[-1].extend([df[col].min(), df[col].max()])
        else:
            result[-1].extend(['-', '-'])
        result[-1].append(description[col])
    
    res = pd.DataFrame(result, columns=['Name', 'Count', 'NA', 'Type', 'Unique', 'Sample', 'min', 'max', 'description']).set_index('Name')
    display(res)
    print(f'Индексы{text.BOLD} {["не ", ""][df.index.is_monotonic_increasing]}упорядочены: {text.END}', end='')
    print(*df.index.to_list()[:10], '...', sep=',', end='\n\n')
    print(f'Размер таблицы: {text.BOLD} {df.shape} {text.END}')
    print(f'Целевой признак: {text.BOLD} {TARGET_COL} {text.END}')

# Вывод информации о всех таблицах:
def display_all(df, names, functions, divider=False):
    size = TABLE_SIZE
    for name in names:
        if divider:
            print('_'*size)
        table_name = ' ТАБЛИЦА ' + name + ' '
        print(text.BOLD, text.BG_SILVER, table_name + table_name.rjust(size-len(table_name)-2, '='), text.END)
        if type(functions) == str:
            display(eval(f"df['{name}'].{functions}"))
        else:
            for func in functions:
                print(text.BOLD, end='')
                print('.'*size)
                print(func.rjust(size))
                print(text.END, end='')
                display(eval(f"df['{name}'].{func}"))
        print()

# остаток данных
def show_remains(data, original_shape):
    display((pd.DataFrame(data.shape, columns=['остаток']).T / original_shape).rename(columns={0:'Строк', 1:'Столбцов'}).style.format({'Строк': '{:.1%}', 'Столбцов': '{:.1%}'}))

# проверка пропусков
def na_info(df, level=0.01):
    sum_table = df.isna().sum()
    na_table = df.count()
    res_table = pd.DataFrame([na_table, sum_table, sum_table / na_table]).T.rename(columns = {0: 'count', 1: 'na', 2: 'fraction'})
    res_table[['count', 'na']] = res_table[['count', 'na']].astype('int')
    
    # Нет пропусков
    print(text.BOLD, text.BG_SILVER, 'Нет пропусков:'.ljust(TABLE_SIZE, ' '), text.END)
    if res_table.query('na == 0').shape[0] > 0:
        display(res_table.query('na == 0').style.format({'fraction': '{:.2%}'}))
    else:
        print(f'\n {text.RED}{text.BOLD} Во всех объектах имеются пропуски {text.END}')
    print()

    # Малая доля (на удаление)
    print(text.BOLD, text.BG_SILVER, 'Малая доля пропусков:'.ljust(TABLE_SIZE, ' '), text.END)
    small = res_table.query('fraction < @level and na > 0')
    if small.shape[0] > 0:
        display(small.style.format({'fraction': '{:.2%}'}))
        remains = df[res_table.query('fraction < @level and na > 0').index].dropna().shape[0] / df.shape[0]
        print(f'Оценка остатка (при удалении пропусков с малой долей): {text.BOLD}{text.BG_YELLOW} {remains:.3%} {text.END}')
    else:
        print(f'\n {text.GREEN}{text.BOLD} Нет пропусков с малой долей {text.END}')
    print()
    
    # Большая доля (на обработку)
    print(text.BOLD, text.BG_SILVER, 'Большая доля пропусков:'.ljust(TABLE_SIZE, ' '), text.END)
    big = res_table.query('fraction > @level')
    if big.shape[0] > 0:
        display(big.style.format({'fraction': '{:.2%}'}))
    else:
        print(f'\n {text.GREEN}{text.BOLD} Нет пропусков с большой долей {text.END}')
    
    return {'delete': list(small.index), 'process': list(big.index)}

#=====================================================================================================================
# Презентации:

# Обзор категориальных признаков
def category_overview(df, col, pie=True):
    print(f'Количество уникальных значений {text.BOLD}{text.BG_SILVER} {df[col].nunique()} {text.END} :')
    display(
        pd.concat([df[col].value_counts(dropna=False).rename('Кол-во значений'), df[col].value_counts(dropna=False, normalize=True).rename('Процент распределения')], axis=1)
        .style.format({'Процент распределения':'{:.2%}'})
    )
    if pie:
        print('-'*TABLE_SIZE)
        df[col].value_counts(dropna=False).plot.pie(figsize=(6, 6), fontsize=12)
        plt.title(f'Объемы значений показателя\n {description[col]}', pad=15, fontsize = 16)
        plt.ylabel('')
        plt.tick_params(labelsize = 18)

# Гистограмма с боксплотом
def hist_box_describe(df, col, subtitle='', xlabel=None, data=None, bins=None, figsize=(8, 8), **kwargs):
    if type(data) == type(None):
        data = df[col]
    if xlabel == None:
        try:
            xlabel = description[col]
        except:
            pass
    if bins == None:
        bins = data.nunique()
    
    fig = plt.figure()
    
    # Разделение fig на зоны разных размеров:
    gs1 = GridSpec(5, 1, left=0.05, right=0.95, hspace=0.03)
    # (y, x) - размеры сетки (высота, ширина)
    # left - расположние левой границы всей сетки (топа margin)
    # right - расположние правой границы всей сетки (топа margin)
    # wspace, hspace - зазоры между графиками (вертикальный, горизонтальный)
    ax1 = fig.add_subplot(gs1[:1, :]) # (срез по Y, срез по X)
    ax2 = fig.add_subplot(gs1[1:, :])
    
    # Построение графиков:
    data.plot(ax=ax1, kind='box', vert=False, widths=0.6, **kwargs)
    data.plot(ax=ax2, kind='hist', grid=True, bins=bins, **kwargs)
    
    # Различные настройки графиков:
    fig.set_figwidth(figsize[0])
    fig.set_figheight(figsize[1])
    #fig.suptitle(f'Распределение показателя "{xlabel}"', fontsize = 16)
    
    ax1.xaxis.tick_top()
    ax2.minorticks_on()
    ax2.grid(which='major',
            color = 'grey', 
            linewidth = 1.2)
    ax2.grid(which='minor', 
            color = 'grey', 
            linestyle = ':')
    
    ax1.set_yticklabels([''])
    ax2.set_xlabel(xlabel, fontsize = 14)
    ax2.set_ylabel('Количество значений', fontsize = 14)
    ax1.tick_params(labelsize = 12)
    ax2.tick_params(labelsize = 12)
    ax1.set_title(f'Распределение показателя "{xlabel}"{subtitle}', pad=15, fontsize = 16)

    x = ax2.get_xbound()
    y = ax2.get_ybound()
    x_coord = x[0] + (x[1]-x[0])/figsize[0]*figsize[1]*0.03 if data.mean() < data.quantile(0.5) else x[1] - (x[1]-x[0])/figsize[0]*figsize[1]*0.36
    y_coord = y[1] - (y[1]-y[0])*0.35
    ax2.text(x_coord, y_coord, str(data.describe()),
        rotation = 0,
        fontsize = figsize[1]*1.2,
        bbox = {'facecolor':'white', 'boxstyle': 'round', 'pad': 1}
            )

# Гистограмма с боксплотом для временного ряда
def date_hist_describe(df, col, subtitle='', xlabel=None, ylabel=None, data=None, bins=100, figsize=(12, 6), **kwargs):
    if type(data) == type(None):
        data = df[col]
    if xlabel == None:
        try:
            xlabel = description[col]
        except:
            pass

    plt.figure(figsize=figsize)
    data.hist(bins=bins)

    plt.title(f'Распределение количества значений по временной шкале\n({xlabel})', pad=15, fontsize = 16)
    plt.xlabel(xlabel, fontsize = 14)
    plt.ylabel('Кол-во значений', fontsize = 14)

    plt.show()
    print(f'{text.BOLD}{text.BG_SILVER} Общая информация по шкале дат: ', text.END)
    display(data.describe())
    
    print(text.BOLD, text.BG_SILVER)
    if data.is_monotonic:
        print('Данные упорядочены в хронологическом порядке')
    else:
        print('Даты не упорядочены')
    print(text.END)

# Многослойная гистограмма с боксплотом
def u_hist_box_describe(data, xlabel, *,
                         labeles=None, subtitle='', describe=True,
                         bins=50, figsize=(10, 10), **kwargs):
    fig = plt.figure()
    
    count = len(data.columns)
    
    # Разделение fig на зоны разных размеров:
    gs1 = GridSpec(7+count, 1, left=0.05, right=0.95, hspace=0.03)
    # (y, x) - размеры сетки (высота, ширина)
    # left - расположние левой границы всей сетки (топа margin)
    # right - расположние правой границы всей сетки (топа margin)
    # wspace, hspace - зазоры между графиками (вертикальный, горизонтальный)
    ax=['']*(count+1)
    ax[count] = fig.add_subplot(gs1[count:, :])
    for i in range(count):
        ax[i] = fig.add_subplot(gs1[i:i+1, :], sharex=ax[-1])
    
    # Построение графиков:
    color = ['darkcyan', 'darkorchid', 'gold', 'firebrick', 'royalblue']
    color_back = [(0/255, 139/255, 139/255, 0.2),
                  (153/255, 50/255, 204/255, 0.2),
                  (255/255, 215/255, 0/255, 0.2),
                  (178/255, 34/255, 34/255, 0.2),
                  (65/255, 105/255, 225/255, 0.2)] # а больше пяти нецелесообразно, будет сливаться все
    i = 0
    for col in data.columns:
        data[col].plot(ax=ax[i], kind='box', vert=False, widths=0.8, color='black', **kwargs)
        data[col].plot(ax=ax[-1], kind='hist', bins=bins, histtype='step', linewidth=2, alpha=0.6+0.4/(count), color=color[i], **kwargs)
        data[col].plot(ax=ax[-1], kind='hist', bins=bins, alpha=1/2/count, color=color[i], label='', **kwargs)
        ax[i].set_facecolor(color_back[i])
        i += 1
    
    # Различные настройки графиков:
    fig.set_figwidth(figsize[0])
    fig.set_figheight(figsize[1])
    #fig.suptitle(f'Распределение показателя "{xlabel}"', fontsize = 16)
    
    ax[0].xaxis.tick_top()
    ax[-1].minorticks_on()
    ax[-1].grid(which='major',
            color = 'darkgrey', 
            linewidth = 1.2)
    ax[-1].grid(which='minor', 
            color = 'darkgrey', 
            linestyle = ':')
    
    for i in range(count):
        ax[i].xaxis.tick_top()
        ax[i].tick_params(labelsize = 6)
        ax[i].set_yticklabels([''])
        #ax[i].legend([label1], fontsize = 12, loc='upper right')
    ax[-1].set_xlabel(xlabel, fontsize = 14)
    ax[-1].set_ylabel('Количество значений', fontsize = 14)
    ax[0].tick_params(labelsize = 12)
    ax[-1].tick_params(labelsize = 12)
    ax[0].set_title(f'Распределение показателя "{xlabel}"{subtitle}', pad=15, fontsize = 16)
    ax[-1].legend(fontsize = 14, loc='upper right')
    
    if describe:
        describe_data = data.describe().drop(['25%', '75%'])
        #display(describe_data)
        bit = 5 - len(str(round(data.mean()[0]//1)))
        x = ax[-1].get_xbound()
        y = ax[-1].get_ybound()
        ax[-1].set_ylim(y[0], y[1]*1.3)
        x_coord = x[0] + (x[1]-x[0])/figsize[0]*figsize[1]*0.03
        y_coord = y[1] - (y[1] - y[0])*0
        ax[-1].text(x_coord, y_coord, str(describe_data.round(bit)),
            rotation = 0,
            fontsize = figsize[1]*1.0,
            bbox = {'facecolor': (0.95, 0.95, 0.95, 0.9), 'boxstyle': 'round', 'pad': 0.6}
                )

# Корреляция признаков
def print_corr(df):
    sns.heatmap(df.corr())
    plt.title('Корреляция признаков', pad=15, fontsize= 14)
    plt.show()
    print(f'Максимальная выявленная корреляция: {text.BOLD}{text.BG_SILVER} {df.corr().replace(1, 0).abs().max().max():.3f} {text.END}')

# Зависимость от целевого бинарного признака
def target_corr_binary(df, col, target, as_category=False, subtitle='', xlabel=None, bins=50, figsize=(7, 7), **kwargs):
    df_in = df[[col, target]].copy()
    if as_category:
        df_in[col] = df_in[col].astype('str')
    
    if xlabel == None:
        try:
            xlabel = description[col]
        except:
            pass
    
    fig, axs = plt.subplots(1, 2, sharey=True)
    plt.subplots_adjust(wspace=0, hspace=1)
    fig.set_figwidth(figsize[0])
    fig.set_figheight(figsize[1])
    fig.suptitle(f'Распределение показателя "{xlabel}"{subtitle}\n в зависимости от целевого признака', fontsize = 16)

    sns.histplot(ax=axs[0], data=df_in.query(f'{target}==0'), y=col, bins=bins, color='tab:blue', label=f'{target} 0', **kwargs) #, element='step'
    sns.histplot(ax=axs[1], data=df_in.query(f'{target}==1'), y=col, bins=bins, color='tab:orange', label=f'{target} 1', **kwargs) #, element='step'

    x_max = max([axs[0].get_xbound()[1], axs[1].get_xbound()[1]])
    y_min, y_max = axs[0].get_ybound()
    axs[0].axis([x_max, 0, y_min, y_max])
    axs[1].axis([0, x_max, y_min, y_max])

    for ax in axs:
        ax.grid(color = 'grey', linestyle = ':')
        ax.spines['top'].set_visible(False)
        ax.set_xlabel('Кол-во значений', fontsize = 14)
        ax.tick_params(labelsize = 12)
        ax.legend(fontsize = 13, loc='best')
    axs[0].set_ylabel(xlabel, fontsize = 14)
    axs[1].spines['right'].set_visible(False)

    plt.show()

# Зависимость от целевого регрессивного признака
def target_corr_reg(df, col, target, as_category=False, subtitle='', ylabel=None, tlabel=None, figsize=(8, 8), **kwargs):
    df_in = df[[col, target]].copy()
    if as_category:
        df_in[col] = df_in[col].astype('str')
    
    if ylabel == None:
        try:
            ylabel = description[col]
            tlabel = description[target]
        except:
            pass
    
    if df_in[col].nunique() < 8 and figsize[1] == 8:
        figsize = (figsize[0], df_in[col].nunique())
    
    plt.figure(figsize=figsize)
    plt.grid(visible=True, axis='both', color = 'grey', linestyle = ':')
    
    sns.histplot(data=df_in, x=target, y=col, **kwargs)
    
    plt.title(f'Распределение показателя "{ylabel}"{subtitle}\n в зависимости от целевого признака', pad=15, fontsize = 16)
    plt.xlabel(tlabel, fontsize = 14)
    plt.ylabel(ylabel, fontsize = 14)
    plt.tick_params(labelsize = 12)
    
    plt.show()

# Нормальное распределение и вероятность выпадения менее required_score
def gaussian_distribution(data, required_score, name='some values', figsize=(10, 8)):
    # Нормальное распределение
    min_value = data.min()
    max_value = data.max()
    
    mu = data.mean()
    sigma = np.std(data, ddof=1)

    x = [i/1000 for i in range(int((mu - 4*sigma)*1000), int((mu + 4*sigma)*1000))]
    distr = st.norm(mu, sigma)
    
    # Построение графика
    fig, ax1 = plt.subplots()
    ax2 = ax1.twinx()
    ax1.plot(x, distr.pdf(x), label = 'Нормальное \nраспределние', color='r', linewidth=4)
    ax2.plot(x, distr.cdf(x), label = 'Вероятности', color='b', linestyle='--', linewidth=2)
    ax2.plot([required_score, required_score], [0, 1], label = 'Искомое \nзначение', linestyle=':', color='g', linewidth=4)

    fig.set_figwidth(figsize[0])
    fig.set_figheight(figsize[1])

    #ax1.xaxis.tick_top()
    ax1.minorticks_on()
    ax1.grid(which='major',
            color = 'grey', 
            linewidth = 1.2)
    ax1.grid(which='minor', 
            color = 'grey', 
            linestyle = ':')

    ax1.legend(fontsize = 12, loc = 'center left')
    ax2.legend(fontsize = 12, loc = 'center right')

    ax1.set_xlabel(f'Значения для {name}', fontsize = 14)
    ax1.set_ylabel('Частота для нормального распределения', fontsize = 14)
    ax2.set_ylabel('Вероятность значения больше данного', fontsize = 14)
    ax1.tick_params(labelsize = 12)
    ax2.tick_params(labelsize = 12)
    ax1.set_title(f'Нормальное распределение {name}\n(набор из {data.shape[0]} значений)', pad=15, fontsize = 16)

    ax2.text(mu - 4*sigma, 0.85, f'Вероятность меньше\nискомого {required_score}:\n{distr.cdf(required_score):.3%}',
            rotation = 0,
            fontsize = min(figsize)*1.75,
            bbox = {'facecolor':'white', 'pad': min(figsize)}
                )
    ax2.text(mu - 4*sigma, 0.3, f'Среднее = {mu:.4f}\nОтклонение = {sigma:.4f}',
            rotation = 0,
            fontsize = min(figsize)*1.5,
            bbox = {'facecolor':'white', 'pad': min(figsize)}
                )
    plt.show()
    print('-'*TABLE_SIZE)
    print(f'\x1b[1mВероятность получить значение меньше {required_score} = \x1b[43m {distr.cdf(required_score):.3%} \x1b[49m\x1b[22m')
    print('-'*TABLE_SIZE)
    print()