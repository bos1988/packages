import pandas as pd
import numpy as np
from statsmodels.tsa.seasonal import seasonal_decompose
from scipy import stats as st
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import get_scorer


# Тренды и сезонность для временных рядов
def trend_season(df, resampling='1D', subtitle=None):
    decomposed = seasonal_decompose(df.resample(resampling).sum())
    if subtitle is None:
        subtitle = resampling

    fig, ax1 = plt.subplots()
    ax2 = ax1.twinx()

    fig.set_figwidth(15)
    fig.set_figheight(5)
    # fig.suptitle(f'Тренды и сезонность\n({subtitle})', fontsize = 16)

    decomposed.seasonal.plot(ax=ax1, linewidth=1.5, color='firebrick', label='Сезонность')
    decomposed.trend.plot(ax=ax2, linewidth=1, color='darkcyan', alpha=0.8, label='Тренд')
    ax2.fill_between(decomposed.trend.index, decomposed.trend, decomposed.trend.min(), color='darkcyan', alpha=0.15)

    ax1.set_ylim([decomposed.seasonal.min() * 1.6, decomposed.seasonal.max() * 1.6])

    ax1.grid(visible=True, axis='x')
    ax1.grid(which='major',
             color='grey',
             axis='x',
             linewidth=1.2)
    ax1.grid(which='minor',
             color='grey',
             linestyle=':')
    ax1.spines['top'].set_visible(False)
    ax2.spines['top'].set_visible(False)
    ax2.margins(0, 0)

    ax1.tick_params(labelsize=12)
    ax2.tick_params(labelsize=12)
    ax1.set_title(f'Тренды и сезонность ({subtitle})', pad=20, fontsize=16)
    ax1.set_xlabel('Временная шкала', fontsize=14)
    ax1.set_ylabel('Кол-во заказов', fontsize=14)
    ax2.set_ylabel('Кол-во заказов', fontsize=14)
    ax1.legend(fontsize=14, loc='upper center', facecolor='mistyrose', framealpha=1)
    ax2.legend(fontsize=14, loc='lower center', facecolor='lightcyan', framealpha=1)


# разбивка на валидационную и тестовую выборки для временных рядов
def research_test_split(df, test_size=0.2, random_state=12345):
    df_research, df_test = train_test_split(df, test_size=test_size, random_state=random_state, shuffle=False)
    print()
    display(pd.DataFrame({
        'Выборка:': ['Исследовательская', 'Тестовая'],
        'Начало': [df_research.index.min(), df_test.index.min()],
        'Конец': [df_research.index.max(), df_test.index.max()],
        'Количество значений:': [df_research.shape[0], df_test.shape[0]],
        'Доля выборки:': [df_research.shape[0] / df.shape[0], df_test.shape[0] / df.shape[0]],
    }).style.format({'Количество значений': '{:.0f}', 'Доля выборки:': '{:.2%}'})
            )
    return df_research, df_test


# Создадим функцию кросс-валидации для временных рядов
# Обучается каждый раз на наборе равном TRAIN_PERIOD. Валидируется по размеру cv
# Вследствие подгонки функции под стандарный вид (для возможности использования в других функциях)
# не могу добавить TRAIN_PERIOD еще одним параметром, поэтому взял глобальную переменную (что, понимаю, не хорошо)
def cross_val_score(estimator, X, y=None, *, scoring=None, cv=5):
    res = []
    step = (len(X) - TRAIN_PERIOD) // cv
    for i in range(cv):
        index_start = i * step
        index_end = index_start + TRAIN_PERIOD

        X_train = X.iloc[index_start:index_end]  # обучающая = длине TRAIN_PERIOD
        X_valid = X.iloc[index_end:index_end + step]  # валидная = (длина(X) - TRAIN_PERIOD) / cv
        y_train = y[X_train.index]
        y_valid = y[X_valid.index]

        estimator.fit(X_train, y_train)
        scorer = get_scorer(scoring)

        res.append(scorer(estimator, X_valid, y_valid))
    return np.array(res)


# ----------------------------------------------------------------------------------
# Анализ результатов

# Гарфики факт/предсказание
def predictions_fact(y_true, predictions, subtitle=None, figsize=(15, 5)):
    if subtitle is None:
        subtitle = ''
    plt.figure(figsize=figsize)
    plt.grid(visible=True, axis='both')

    plt.grid(visible=True, axis='x')
    plt.grid(which='major',
             color='grey',
             axis='x',
             linewidth=1.2)
    plt.grid(which='minor',
             color='grey',
             linestyle=':')

    y_true.plot(linewidth=1.5, color='darkblue', label='Фактические данные')
    predictions.plot(linewidth=1.5, color='darkcyan', alpha=0.8, label='Предсказания')
    plt.fill_between(y_true.index, y_true, predictions, color='salmon', alpha=0.2, label='Разница')
    plt.fill_between(y_true.index, y_true - predictions, np.zeros(y_true.shape[0]), color='salmon', alpha=0.4)

    plt.tick_params(labelsize=12)

    plt.title(f'График факта/предсказаний {subtitle}', pad=15, fontsize=16)
    plt.xlabel('Временная шкала', fontsize=14)
    plt.ylabel('Кол-во заказов', fontsize=14)
    plt.legend(fontsize=12, loc='upper center')


# Анализ остатков
def predictions_remains(y_true, predictions, figsize=(12, 12)):
    remains = y_true - predictions

    mu = remains.mean()
    sigma = np.std(remains, ddof=1)
    sigma_width = 4

    x = [i for i in range(int(mu - sigma_width * sigma), int(mu + sigma_width * sigma))]
    distr = st.norm(mu, sigma)

    plt.figure(figsize=(figsize[0] / 2, figsize[1] / 3))
    remains.plot(kind='hist', bins=100, histtype='step', linewidth=0.5, color='darkslategrey')
    remains.plot(kind='hist', bins=100, color='darkcyan', alpha=0.5)
    plt.plot(x, distr.pdf(x) * remains.shape[0] * int(sigma_width * 2 * sigma) / 100, label='Нормальное \nраспределние',
             color='firebrick', linewidth=1.5, linestyle='--')

    plt.title('Нормальное распределение', pad=15, fontsize=16)
    plt.xlabel('Разница факт/предсказание', fontsize=12)
    plt.ylabel('Количество значений', fontsize=12)

    plt.show()

    plt.figure(figsize=(figsize[0] / 2, figsize[1] / 3))
    plt.scatter(predictions, remains, s=30, color='darkcyan', alpha=0.3)
    plt.title('Разброс ошибок', pad=15, fontsize=16)
    plt.xlabel('Значения предсказаний', fontsize=12)
    plt.ylabel('Разница факт/предсказание', fontsize=12)
    plt.text(predictions.min() * 1.01, remains.max() - (remains.max() - remains.min()) * 0.15,
             f'Корреляция:\n{predictions.corr(remains):.4f}',
             rotation=0,
             fontsize=12)

    plt.show()

    plt.figure(figsize=(figsize[0], figsize[1] / 3))
    remains.plot(kind='bar', width=1, color='darkcyan')
    plt.plot([0, remains.shape[0]], [0, 0], linewidth=1.1, color='firebrick')
    plt.title('Автокорреляция отстатков', pad=15, fontsize=16)
    plt.xlabel('Временная шкала', fontsize=12)
    plt.ylabel('Разница факт/предсказание', fontsize=12)
    plt.xticks([])

    plt.show()
