from dsbudin.formattext import text
from dsbudin import math as budin_math

import pandas as pd
import numpy as np

import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

from scipy import stats as st
from sklearn.ensemble import IsolationForest


class Options:
    """Module settings:
    
Attributes
----------
TABLE_SIZE = 100
    Horizontal lines width

FONTSIZE_LABEL = 14
    Font size for axis labels

FONTSIZE_TITLE = 16
    Font size for graph names

LANG = 'EN'
    The language of the output text: 'RU' or 'EN'
    """
    TABLE_SIZE = 100
    FONTSIZE_LABEL = 14
    FONTSIZE_TITLE = 16
    LANG = 'EN'

    def __repr__(self):
        return f'TABLE_SIZE = {self.TABLE_SIZE}\n\
FONTSIZE_LABEL = {self.FONTSIZE_LABEL}\n\
FONTSIZE_TITLE = {self.FONTSIZE_TITLE}\n\
LANG = {self.LANG}\n\
'


options = Options()
description = {}


# ---------------------------------------------------------------------------------------------------------------------
# Processing:


def snake_to_camel(string, sep='_'):
    """Translation from camel to snake register

Parameters
----------
string: str
    Camel register text

sep: str, default='_'
    Camel register separator

Returns
-------
camel: str
    Text in Snake Register
"""
    return ''.join([i.replace(i[0], i[0].upper(), 1) for i in string.split(sep)])


def camel_to_snake(string, sep='_'):
    """Translation from camel to snake register

Parameters
----------
string: str
    Camel register text

sep: str, default='_'
    Snake register separator

Returns
-------
camel: str
    Text in Snake Register
"""
    camel = ''
    for i in range(len(string)):
        camel += sep if string[i].isupper() and string[i - 1].islower() else ''
        camel += string[i].lower()
    return camel.lstrip(sep)


def description_snake_to_camel(description_dict):
    """Translation of data Description Dictionary keys from Camel to Snake register

Parameters
----------
description_dict: dict
    Dictionary of data description with keys in Camel register

Returns
-------
camel_description: dict
    Dictionary of data description with keys in the Snake register
"""
    camel_description = dict()
    for key, val in description_dict.items():
        camel_description[snake_to_camel(key)] = val
    return camel_description


def description_camel_to_snake(description_dict):
    """Translation of data Description Dictionary keys from Camel to Snake register

Parameters
----------
description_dict: dict
    Dictionary of data description with keys in Camel register

Returns
-------
camel_description: dict
    Dictionary of data description with keys in the Snake register
"""
    camel_description = dict()
    for key, val in description_dict.items():
        camel_description[camel_to_snake(key)] = val
    return camel_description


def set_true_int_for_float(df, int_type='int64', lang=None, report=True):
    """Converting the float values with the remainder .0 to the int type

Parameters
----------
df: pandas.DataFrame
    Input data table

int_type: str, default='int64'
    Int type in the required dimension

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

report: bool, default=True
    Display information about the changes made

Returns
-------
df_int: pandas.DataFrame
    New table with set integer types
"""
    texts = [
        {'EN': "Data type changed from 'float' to 'int' for columns",
         'RU': "Тип данных изменен с 'float' на 'int' для столбцов"},
    ]
    if lang is None:
        lang = options.LANG
    
    df_int = df.copy()
    if report:
        print(f"{texts[0][lang]}:\n")
    for col in df_int.select_dtypes('float'):
        if df_int[col].isna().sum() == 0 and (df_int[col] % 1).sum() == 0:
            df_int[col] = df_int[col].astype(int_type)
            if report:
                print(f"{text.BOLD} {col} {text.END}\n")
    return df_int


def set_category_type(df, cat_features):
    """Converting features to the category data type

Parameters
----------
df: pandas.DataFrame
    Input data table

cat_features: array-like
    Names of features to replace the type with a categorical one

Returns
-------
df_cat: pandas.DataFrame
    New table with established types of categorical features
"""
    df_cat = df.copy()
    df_cat[cat_features] = df_cat[cat_features].astype('category')
    return df_cat


def big_number(val):
    """Beautiful display of large numbers

Parameters
----------
val: numeric
    Number

Returns
-------
res: str
    Number of type str with apostrophes
"""
    dec = str(round(val * 100 % 100))
    s = list(str(round(val)).lstrip('-'))
    for i in range(0, len(s) - 1, 4):
        s.insert(-i - 3, '`')
    return ('', '-')[int(val < 0)] + ''.join(s) + '.' + dec


def get_corr_target(data, target):
    """Get features correlation with target feature

Parameters
----------
data: pandas.DataFrame
    Input data table

target: str
    Name of the column with the target feature

Returns
-------
df_corr: pandas.DataFrame
    Correlation Coefficients table
"""
    corrs = []
    columns = data.select_dtypes('number').columns
    for name in columns:
        corrs.append(data[name].corr(data[target]))
    return pd.DataFrame({'corr': corrs}, index=columns)


def find_anomaly(df, target, *, offset=-2/3, display=False, random_state=None, **kwargs):
    """Getting indexes of abnormal values
Used Isolation Forest Algorithm

Parameters
----------
df: pandas.DataFrame
    Input data table

target: str
    Name of the column with the target feature

offset: float, default=-2/3
    offset = -2/3 is a good coefficient that cleans up small accumulations of emissions (about 1%)
    offset = -0.75 is removes only the MOST distant (less than 0.5%)

display: bool, default=False
    Display ScatterPlots with anomalies for each feature

random_state: int, RandomState instance, default=None
    Controls the randomness

**kwargs:
    Properties, optional
    for IsolationForest

Returns
-------
df_corr: pandas.DataFrame
    Correlation Coefficients table
"""
    model = IsolationForest(max_samples=1.0, random_state=random_state, n_jobs=-1, **kwargs)
    result = set()
    
    for col in df.drop(target, axis=1).select_dtypes('number').columns:
        test_df = df[[col, target]].dropna()
        model.fit(test_df.values)
        model.offset_ = offset
        
        predictions = model.predict(test_df.values)
        result |= set(test_df[predictions == -1].index)
        
        if display:
            test_df['predict'] = predictions
            test_df['predict'] = test_df['predict'].replace(-1, 'anomaly')
            test_df['predict'] = test_df['predict'].replace(1, 'normal')
            print_scatter(test_df, col, target, hue='predict')
            print('COUNT ANOMALIES:', (predictions == -1).sum(), '\n\n')
    
    return list(result)


class NaFiller:
    """Filling in gaps in a Dataframe

Categorical omissions are filled in with the value `unknown`
Numerical gaps are filled in according to a given strategy
"""
#     set_names = ['fill_mean', 'fill_median', 'fill_mode', 'fill_zero', 'fill_negative']
    
    def __init__(self, *, fill_mean=None, fill_median=None, fill_mode=None, fill_zero=None, fill_negative=None):
        """Creating an object of the NaFiller class

Parameters
----------
fill_mean: list
    Names of columns to fill with average values

fill_median: list
    Names of columns to fill with median values

fill_mode: list
    Names of columns to fill with mods

fill_zero: list
    Column names to fill with zeros

fill_negative: list
    Names of columns to fill with -1 values

Returns
-------
NaFiller: NaFiller
    An object of the NaFiller class
"""
        self.sets = {
            'fill_mean': [],
            'fill_median': [],
            'fill_mode': [],
            'fill_zero': [],
            'fill_negative': [],
        }
        for name in self.sets:
            exec(f"""
if {name} is not None:
    self.sets['{name}'] = {name}
""")
        
        self._means = None
        self._medians = None
        self._modes = None
        
        self.fitted = False

    def fit(self, df, blank=None):
        """Settings for filling in gaps

Parameters
----------
df: pandas.DataFrame
    Input data table

Returns
-------
None
    Fitted NaFiller object
"""
        if self.sets['fill_mean']:
            self._means = df[self.sets['fill_mean']].mean()
        if self.sets['fill_median']:
            self._medians = df[self.sets['fill_median']].median()
        if self.sets['fill_mode']:
            self._modes = df[self.sets['fill_mode']].mode().T[0]  # mode возвращает DataFrame
        
        self.fitted = True
        
        return self

    def transform(self, df, blank=None):
        """Filling in the gaps

Parameters
----------
df: pandas.DataFrame
    Input data table

Returns
-------
df_filled: pandas.DataFrame
    Dataframe with filled-in gaps
"""
        df_f = df.copy()
        
        for col in self.sets['fill_mean']:
            if col in df:
                df_f[col] = df_f[col].fillna(self._means.loc[col])

        for col in self.sets['fill_median']:
            if col in df:
                df_f[col] = df_f[col].fillna(self._medians.loc[col])

        for col in self.sets['fill_mode']:
            if col in df:
                df_f[col] = df_f[col].fillna(self._modes.loc[col])

        for col in self.sets['fill_zero']:
            if col in df:
                df_f[col] = df_f[col].fillna(0)

        for col in self.sets['fill_negative']:
            if col in df:
                df_f[col] = df_f[col].fillna(-1)

        for col in df_f:
            if df_f[col].dtype == 'category':
                df_f[col] = df_f[col].astype('object').fillna('unknown').astype('category')
            if df_f[col].dtype == 'object':
                df_f[col] = df_f[col].fillna('unknown')

        return df_f
    
    def __call__(self, df):
        return self.transform(df)

    def __str__(self):
        
        res1 = 'NaFiller '
        res2 = ('(Not Fitted)', '(Fitted)')[self.fitted]
        res3 = '\n'
        for name in ['fill_zero', 'fill_negative']:
            if not self.sets[name]:
                continue
            res3 += f'\n{name}:\n'
            for i in self.sets[name]:
                res3 += '    ' + str(i) + '\n'
        
        res4 = ''
        if self._means is not None:
            res4 += f'\n\nmeans:\n\n{self._means}'
        if self._medians is not None:
            res4 += f'\n\nmedians:\n\n{self._medians}'
        if self._modes is not None:
            res4 += f'\n\nmodes:\n\n{self._modes}'
            
#         res4 = f'means:\n\n{self._means}\n\nmedians:\n\n{self._medians}\n\nmodes:\n\n{self._modes}'
        return res1 + res2 + res3 + res4


# ---------------------------------------------------------------------------------------------------------------------
# Informing:


def print_description(df):
    """Data description output

Parameters
----------
df: pandas.DataFrame
    Input data table

Returns
-------
print: None
    Display data description dictionary
"""
    len_index = max([len(i) for i in df])
    for ind, name in enumerate(df):
        end = '' if len(description[name]) < options.TABLE_SIZE else '...'
        print(f'{str(ind).ljust(3)} {name.ljust(len_index)} - {description[name][:options.TABLE_SIZE]}{end}')


def start_information(df, sort_by=None, ascending=True, lang=None):
    """General information about the data in the table

Parameters
----------
df: pandas.DataFrame
    Input data table

sort_by: str or list of str, default=None
    Name or list of names to sort by

ascending: bool or list of bool, default=True
    Sort ascending vs. descending. Specify list for multiple sort orders.
    If this is a list of bools, must match the length of the by.

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

Returns
-------
print: None
    Displaying a general table of data information
"""
    texts = [
        {'EN': 'Indexes are', 'RU': 'Индексы'},
        {'EN': 'not ', 'RU': 'не '},
        {'EN': 'ordered', 'RU': 'упорядочены'},
        {'EN': 'Number of explicit duplicates', 'RU': 'Количество явных дубликатов'},
        {'EN': 'Table size', 'RU': 'Размер таблицы'},
        # {'EN': 'Target column', 'RU': 'Целевой признак'},
    ]
    if lang is None:
        lang = options.LANG
    
    result = []
    for col in df:
        result.append([
            col, df[col].count(), df[col].isna().sum(),
            str(df[col].dtype), df[col].nunique(), df[col].sample(10).values,
        ])
        if str(df[col].dtype)[:3] in 'intflo':
            result[-1].extend([df[col].min(), df[col].max()])
        else:
            result[-1].extend(['-', '-'])
        result[-1].append(description[col])

    res = pd.DataFrame(result,
                       columns=['Name', 'Count', 'NA', 'Type', 'Unique', 'Sample', 'min', 'max', 'description']) \
        .set_index('Name')
    if not (sort_by is None):
        res = res.sort_values(by=sort_by, ascending=ascending)
    display(res)
    print(f'{texts[0][lang]}{text.BOLD} \
{[texts[1][lang], ""][df.index.is_monotonic_increasing]}{texts[2][lang]}: {text.END}', end='')
    print(*df.index.to_list()[:10], '...', sep=',', end='\n\n')
    print(f'{texts[3][lang]}: {text.BOLD} {df.duplicated().sum()} {text.END}', end='\n\n')
    print(f'{texts[4][lang]}: {text.BOLD} {df.shape} {text.END}')
    # print(f'{texts[4][lang]}: {text.BOLD} {options.TARGET_COL} {text.END}')


def display_all(df, names, functions, divider=False, lang=None):
    """Output of the specified information for all tables:

Parameters
----------
df: dict{str: pandas.DataFrame}
    Vocabulary with input tables

names: list
    List of names of the tables under consideration

functions: str or list
    Called methods. For example: 'info()' or ['head()', 'info()', 'nunique()']

divider: bool, default=False
    Display separator

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

Returns
-------
print: None
    Displaying information on tables
"""
    texts = [
        {'EN': ' TABLE ', 'RU': ' ТАБЛИЦА '},
    ]
    if lang is None:
        lang = options.LANG
    
    size = options.TABLE_SIZE
    for name in names:
        if divider:
            print('_' * size)
        table_name = texts[0][lang] + name + ' '
        print(text.BOLD, text.BG_SILVER, table_name + table_name.rjust(size - len(table_name) - 2, '='), text.END)
        if type(functions) == str:
            display(eval(f"df['{name}'].{functions}"))
        else:
            for func in functions:
                print(text.BOLD, end='')
                print('.' * size)
                print(func.rjust(size))
                print(text.END, end='')
                display(eval(f"df['{name}'].{func}"))
        print()


def show_remains(data, original_shape, lang=None):
    """Displays the remaining data

Parameters
----------
data: pandas.DataFrame
    Input data table

original_shape: 2-tuple
    Dimension of the original data frame

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

Returns
-------
print`: None
    Displaying the percentage of the remaining data in comparison with the source table
"""
    texts = [
        {'EN': 'remains', 'RU': 'остаток'},
        {'EN': 'Rows', 'RU': 'Строк'},
        {'EN': 'Columns', 'RU': 'Столбцов'},
    ]
    if lang is None:
        lang = options.LANG
    
    display((pd.DataFrame(data.shape, columns=[texts[0][lang]]).T / original_shape)
            .rename(columns={0: texts[1][lang], 1: texts[2][lang]})
            .style.format({texts[1][lang]: '{:.1%}', texts[2][lang]: '{:.1%}'}))


def na_info(df, level=0.01, lang=None):
    """Pass check

Parameters
----------
df: pandas.DataFrame
    Input data table

level: float, default=0.01
    The percentage of omissions accepted as small

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

Returns
-------
print: None
    Displays pass information

columns: dict
    'delete': A list of columns with a small percentage of omissions that can be deleted
    'process': A list of columns with a large proportion of omissions that need to be processed
"""
    texts = [
        {'EN': 'No omissions', 'RU': 'Нет пропусков:'},
        {'EN': 'There are omissions in all objects', 'RU': 'Во всех объектах имеются пропуски'},
        {'EN': 'Small percentage of omissions:', 'RU': 'Малая доля пропусков:'},
        {'EN': 'Estimation of the remainder (when deleting omissions with a small percentage):',
         'RU': 'Оценка остатка (при удалении пропусков с малой долей):'},
        {'EN': 'No omissions with a small percentage', 'RU': 'Нет пропусков с малой долей'},
        {'EN': 'A large percentage of omissions:', 'RU': 'Большая доля пропусков:'},
        {'EN': 'There are no omissions with a large percentage', 'RU': 'Нет пропусков с большой долей'},
    ]
    if lang is None:
        lang = options.LANG
    
    sum_table = df.isna().sum()
    na_table = df.count()
    res_table = pd.DataFrame([na_table, sum_table, sum_table / df.shape[0]]).T.rename(
        columns={0: 'count', 1: 'na', 2: 'fraction'})
    res_table[['count', 'na']] = res_table[['count', 'na']].astype('int')

    # No passes
    print(text.BOLD, text.BG_SILVER, texts[0][lang].ljust(options.TABLE_SIZE, ' '), text.END)
    if res_table.query('na == 0').shape[0] > 0:
        display(res_table.query('na == 0').style.format({'fraction': '{:.2%}'}))
    else:
        print(f'\n {text.RED}{text.BOLD} {texts[1][lang]} {text.END}')
    print()

    # Small fraction (for deletion)
    print(text.BOLD, text.BG_SILVER, texts[2][lang].ljust(options.TABLE_SIZE, ' '), text.END)
    small = res_table.query('fraction < @level and na > 0')
    if small.shape[0] > 0:
        display(small.style.format({'fraction': '{:.2%}'}))
        remains = df[res_table.query('fraction < @level and na > 0').index].dropna().shape[0] / df.shape[0]
        print(f'{texts[3][lang]} {text.BOLD}{text.BG_YELLOW} {remains:.3%} {text.END}')
    else:
        print(f'\n {text.GREEN}{text.BOLD} {texts[4][lang]} {text.END}')
    print()

    # Large share (for processing)
    print(text.BOLD, text.BG_SILVER, texts[5][lang].ljust(options.TABLE_SIZE, ' '), text.END)
    big = res_table.query('fraction > @level')
    if big.shape[0] > 0:
        display(big.style.format({'fraction': '{:.2%}'}))
    else:
        print(f'\n {text.GREEN}{text.BOLD} {texts[6][lang]} {text.END}')

    return {'delete': list(small.index), 'process': list(big.index)}


# ---------------------------------------------------------------------------------------------------------------------
# Presentations:


def category_overview(df, col, pie=True, figsize=(6, 6), fontsize_title=None, lang=None, **kwargs):
    """Overview of categorical features

Parameters
----------
df: pandas.DataFrame
    Input data table

col: str
    Name of the column with the feature under consideration

pie: bool, default=True
    Display Graph

figsize: 2-tuple of floats, default=(6, 6)
    Figure dimension (width, height) in inches.

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

**kwargs:
    Properties, optional
    for df.plot.pie

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Count of unique values', 'RU': 'Количество уникальных значений'},
        {'EN': 'Count of values', 'RU': 'Кол-во значений'},
        {'EN': 'Percentage of distribution', 'RU': 'Процент распределения'},
        {'EN': 'Volumes of values for parameter', 'RU': 'Объемы значений показателя'},
    ]
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    print(f'{texts[0][lang]} {text.BOLD}{text.BG_SILVER} {df[col].nunique()} {text.END} :')
    display(
        pd.concat(
            [df[col].value_counts(dropna=False).rename(texts[1][lang]),
             df[col].value_counts(dropna=False, normalize=True).rename(texts[2][lang])],
            axis=1)
        .style.format({texts[2][lang]: '{:.2%}'})
    )
    if pie:
        print('-' * options.TABLE_SIZE)
        df[col].value_counts(dropna=False).plot.pie(figsize=figsize, fontsize=12, **kwargs)
        plt.title(f'{texts[3][lang]}\n "{description[col]}"', pad=15, fontsize=fontsize_title)
        plt.ylabel('')
        plt.tick_params(labelsize=18)


def hist_box_describe(df, col, xlabel=None, data=None, bins=None, fdist=None, kwargdist=None,
                      subtitle='', figsize=(9, 9), fontsize_label=None, fontsize_title=None, lang=None, **kwargs):
    """Histogram with boxplot

Parameters
----------
df: pandas.DataFrame
    Input data table

col: str
    Name of the column with the feature under consideration

xlabel: str, default=None
    X-Axis Label

data: pandas.Series, default=None
    Table of input data in case you need to consider data not from df

bins: int, default=None
    Number of histogram bins to be used

fdist: Scipy Continuous distributions, default=None
    A function for plotting a distribution graph containing the `.pdf` method

kwargdist: dict, default=None
    Dictionary with arguments passed to the function for plotting the distribution

subtitle: str, default=''
    Additional text in the title of the graph

figsize: 2-tuple of floats, default=(9, 9)
    Figure dimension (width, height) in inches.

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

**kwargs:
    Properties, optional
    for pd.plot.hist

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Count of values', 'RU': 'Количество значений'},
        {'EN': 'Distribution for parameter', 'RU': 'Распределение показателя'},
        {'EN': 'For significance levels greater than', 'RU': 'Для уровней значимости более'},
        {'EN': 'it is possible to reject the null hypothesis\n\
that the data are distributed according to the theoretical law under consideration',
         'RU': 'можно отвергать нулевую гипотезу, о том\n\
что данные распределены по рассматриваемому теоретическому закону'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    if data is None:
        data = df[col].dropna()  # ! remove NaN ! (with NaN error when plotting distributions)
    if xlabel is None:
        xlabel = description.get(col)
    if bins is None:
        bins = data.nunique()

    fig = plt.figure()

    # Разделение fig на зоны разных размеров:
    gs1 = GridSpec(7, 1, left=0.05, right=0.95, hspace=0.03)
    # (y, x) - размеры сетки (высота, ширина)
    # left - расположение левой границы всей сетки (топа margin)
    # right - расположение правой границы всей сетки (топа margin)
    # wspace, hspace - зазоры между графиками (вертикальный, горизонтальный)
    ax1 = fig.add_subplot(gs1[:1, :])  # (срез по Y, срез по X)
    ax2 = fig.add_subplot(gs1[1:, :])

    # Graphing
    # Boxplot and histogram
    data.plot(ax=ax1, kind='box', vert=False, widths=0.6)
    data.plot(ax=ax2, kind='hist', grid=True, bins=bins, **kwargs)

    # Theoretical distribution (if specified)
    alpha_fact = 0
    if not (fdist is None):
        if kwargdist is None:
            kwargdist = {'loc': np.mean(data), 'scale': np.std(data, ddof=0)}
        x_minmax = min(data), max(data)
        h = (x_minmax[1] - x_minmax[0]) / bins
        xs = np.linspace(*x_minmax, bins)
        # Theoretical frequencies
        ys = fdist.pdf(x=xs, **kwargdist) * len(data) * h
        # Actual frequencies:
        w_fact = np.histogram(data, bins)[0]
        # Сгладим неоправданно большое расхождение между малыми частотами по краям выборки:
        indexes = np.where(w_fact > len(data) / bins * 0.5)
        # The value of the observed statistical criterion:
        r = len(kwargdist)
        k = bins - r - 1
        u = ((np.histogram(data, bins)[0] - ys) ** 2 / ys)[indexes].sum()
        pvalue = st.chi2.cdf(u, k)
        # Significance criterion:
        alpha_fact = 1 - pvalue
        # Graph
        ax2.plot(xs, ys, '--', linewidth=2.5)

    # Various chart settings:
    fig.set_figwidth(figsize[0])
    fig.set_figheight(figsize[1])

    ax1.xaxis.tick_top()
    ax2.minorticks_on()
    ax2.grid(which='major',
             color='grey',
             linewidth=1.0)
    ax2.grid(which='minor',
             color='grey',
             linestyle=':',
             linewidth=0.8)

    ax1.set_yticklabels([''])
    ax2.set_xlabel(xlabel, fontsize=fontsize_label)
    ax2.set_ylabel(texts[0][lang], fontsize=fontsize_label)
    ax1.tick_params(labelsize=12)
    ax2.tick_params(labelsize=12)
    ax1.set_title(f'{texts[1][lang]}\n"{xlabel}"\n{subtitle}', pad=15, fontsize=fontsize_title)

    x = ax2.get_xbound()
    y = ax2.get_ybound()
    x_coord = x[0] + (x[1] - x[0]) / figsize[0] * figsize[1] * 0.03 if data.mean() < data.quantile(0.5) else x[1] - (
            x[1] - x[0]) / figsize[0] * figsize[1] * 0.27
    y_coord = y[1] - (y[1] - y[0]) * 0.27
    graph_text = '\n'.join(str(data.describe()).split('\n')[:-1])
    ax2.text(x_coord, y_coord, graph_text,
             rotation=0,
             fontsize=figsize[1] * 1.2,
             bbox={'facecolor': 'white', 'boxstyle': 'round', 'pad': 1, 'alpha': 0.8}
             )
    plt.show()
    if not (fdist is None):
        horizont = f'{text.RED}{"-" * int(len(texts[3][lang]) * 0.75)}{text.END}'
        print(horizont)
        print(f'{texts[2][lang]} {text.BG_SILVER}{text.BOLD} {alpha_fact:.2%} {text.END} {texts[3][lang]}')
        print(horizont)


def date_hist_describe(df, col, xlabel=None, data=None, bins=100,
                       subtitle='', figsize=(12, 6), fontsize_label=None, fontsize_title=None, lang=None, **kwargs):
    """Histogram with a boxplot for a time series

Parameters
----------
df: pandas.DataFrame
    Input data table

col: str
    Name of the column with the feature under consideration

xlabel: str, default=None
    X-Axis Label

data: pandas.Series, default=None
    Table of input data in case you need to consider data not from df

bins: int, default=100
    Number of histogram bins to be used

subtitle: str, default=''
    Additional text in the title of the graph

figsize: 2-tuple of floats, default=(12, 6)
    Figure dimension (width, height) in inches.

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

**kwargs:
    Properties, optional
    for pd.hist

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Distribution of the count of values on the timeline',
         'RU': 'Распределение количества значений по временной шкале'},
        {'EN': 'Count of values', 'RU': 'Кол-во значений'},
        {'EN': 'General information on the date scale', 'RU': 'Общая информация по шкале дат'},
        {'EN': 'The data is arranged in chronological order', 'RU': 'Данные упорядочены в хронологическом порядке'},
        {'EN': 'Dates are not ordered', 'RU': 'Даты не упорядочены'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    if data is None:
        data = df[col]
    if xlabel is None:
        xlabel = description.get(col)

    plt.figure(figsize=figsize)
    data.hist(bins=bins, **kwargs)

    plt.title(f'{texts[0][lang]}\n({xlabel}){subtitle}', pad=15, fontsize=fontsize_title)
    plt.xlabel(xlabel, fontsize=fontsize_label)
    plt.ylabel(texts[1][lang], fontsize=fontsize_label)

    plt.show()
    print(f'{text.BOLD}{text.BG_SILVER} {texts[2][lang]}: ', text.END)
    display(data.describe())

    print(text.BOLD, text.BG_SILVER)
    if data.is_monotonic_increasing:
        print(texts[3][lang])
    else:
        print(texts[4][lang])
    print(text.END)


def u_hist_box_describe(data, xlabel, *, bins=50, describe=True,
                        subtitle='', figsize=(10, 10), fontsize_label=None, fontsize_title=None, lang=None, **kwargs):
    """Multilayer histogram with boxplotм

Parameters
----------
data: pandas.DataFrame
    Input data table

xlabel: str
    X-Axis Label

bins: int, default=50
    Number of histogram bins to be used

describe: bool, default=True
    Display statistical information on a graph

subtitle: str, default=''
    Additional text in the title of the graph

figsize: 2-tuple of floats, default=(10, 10)
    Figure dimension (width, height) in inches.

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

**kwargs:
    Properties, optional
    for pd.plot.hist

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Count of values', 'RU': 'Количество значений'},
        {'EN': 'Distribution for parameter', 'RU': 'Распределение показателя'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    fig = plt.figure()

    count = len(data.columns)

    # Разделение fig на зоны разных размеров:
    gs1 = GridSpec(7 + count, 1, left=0.05, right=0.95, hspace=0.03)
    # (y, x) - размеры сетки (высота, ширина)
    # left - расположение левой границы всей сетки (топа margin)
    # right - расположение правой границы всей сетки (топа margin)
    # wspace, hspace - зазоры между графиками (вертикальный, горизонтальный)
    ax = [plt.axes()] * (count + 1)
    ax[count] = fig.add_subplot(gs1[count:, :])
    for i in range(count):
        ax[i] = fig.add_subplot(gs1[i:i + 1, :], sharex=ax[-1])

    # Plotting:
    color = ['darkcyan', 'darkorchid', 'gold', 'firebrick', 'royalblue']
    color_back = [(0 / 255, 139 / 255, 139 / 255, 0.2),
                  (153 / 255, 50 / 255, 204 / 255, 0.2),
                  (255 / 255, 215 / 255, 0 / 255, 0.2),
                  (178 / 255, 34 / 255, 34 / 255, 0.2),
                  (65 / 255, 105 / 255, 225 / 255, 0.2)]
    # а больше пяти нецелесообразно, будет сливаться все
    i = 0
    for col in data.columns:
        data[col].plot(ax=ax[i], kind='box', vert=False, widths=0.8, color='black')
        data[col].plot(ax=ax[-1], kind='hist', bins=bins, histtype='step', linewidth=2, alpha=0.6 + 0.4 / count,
                       color=color[i], **kwargs)
        data[col].plot(ax=ax[-1], kind='hist', bins=bins, alpha=1 / 2 / count, color=color[i], label='', **kwargs)
        ax[i].set_facecolor(color_back[i])
        i += 1

    # Various chart settings:
    fig.set_figwidth(figsize[0])
    fig.set_figheight(figsize[1])

    ax[0].xaxis.tick_top()
    ax[-1].minorticks_on()
    ax[-1].grid(which='major',
                color='darkgrey',
                linewidth=1.2)
    ax[-1].grid(which='minor',
                color='darkgrey',
                linestyle=':')

    for i in range(count):
        ax[i].xaxis.tick_top()
        ax[i].tick_params(labelsize=6)
        ax[i].set_yticklabels([''])
    ax[-1].set_xlabel(xlabel, fontsize=fontsize_label)
    ax[-1].set_ylabel(texts[0][lang], fontsize=fontsize_label)
    ax[0].tick_params(labelsize=12)
    ax[-1].tick_params(labelsize=12)
    ax[0].set_title(f'{texts[1][lang]} "{xlabel}"{subtitle}', pad=15, fontsize=fontsize_title)
    ax[-1].legend(fontsize=fontsize_label, loc='upper right')

    if describe:
        describe_data = data.describe().drop(['25%', '75%'])
        bit = 5 - len(str(round(data.mean()[0] // 1)))
        x = ax[-1].get_xbound()
        y = ax[-1].get_ybound()
        ax[-1].set_ylim(y[0], y[1] * 1.3)
        x_coord = x[0] + (x[1] - x[0]) / figsize[0] * figsize[1] * 0.03
        y_coord = y[1] - (y[1] - y[0]) * 0
        ax[-1].text(x_coord, y_coord, str(describe_data.round(bit)),
                    rotation=0,
                    fontsize=figsize[1] * 1.0,
                    bbox={'facecolor': (0.95, 0.95, 0.95, 0.9), 'boxstyle': 'round', 'pad': 0.6}
                    )


def print_scatter(df, x, y,
                  subtitle='', figsize=(9, 9), alpha=True,
                  fontsize_label=None, fontsize_title=None, lang=None,
                  **kwargs):
    """Drawing a scatter plot

Parameters
----------
df: pandas.DataFrame
    Input data table

x, y: keys in df
    Variables that specify positions on the x and y axes. 

subtitle: str, default=''
    Additional text in the title of the graph

alpha: bool, default=True
    Setting Adaptive transparency

figsize: 2-tuple of floats, default=(9, 9)
    Figure dimension (width, height) in inches.

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

**kwargs:
    Properties, optional
    for sns.scatterplot

Returns
-------
graph: None
    A graph is being built
"""
    xlabel = description.get(x, x)
    ylabel = description.get(y, y)

    texts = [
        {'EN': 'Scatter plot with linear regression', 'RU': 'Диаграмма рассеяния с линейной регрессией'},
        {'EN': 'Correlation', 'RU': 'Корреляция'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    if alpha:
        alpha = (1 - k) ** 2 if (k := np.log10(len(df[x])) / 10) >= 0.1 else 1
    else:
        alpha = 1
    
    plt.figure(figsize=figsize)
    
    sns.scatterplot(data=df, x=x, y=y, alpha=alpha, **kwargs)

    if df[x].dtype == 'datetime64[ns]':
        # x_values = df[x].astype(int) / 10e8 / 3600 / 24  # для временного ряда
        x_values = (df[x] - pd.Timestamp('01-01-1970')).dt.days  # для временного ряда
    else:
        x_values = df[x]
    
    a = x_values.cov(df[y], ddof=0) / x_values.var(ddof=0)
    b = df[y].mean() - a * x_values.mean()
    # Обработаем выход линии за границы значений:
    x_bound = min(x_values), max(x_values)  # plt.xlim()
    y_bound = min(df[y]), max(df[y])  # plt.ylim()
    
    xl = (df[y].min() - b) / a
    xg = (df[y].max() - b) / a
    if a > 0:
        xs = [max(x_bound[0], xl), min(x_bound[1], xg)]
    else:
        xs = [max(x_bound[0], xg), min(x_bound[1], xl)]
    plt.plot(xs, list(map(lambda r: a * r + b, xs)), ',-', color='tomato', linewidth=2.5, markersize=12)

    plt.grid(which='major',
             color='grey',
             linestyle=':')
    plt.tick_params(labelsize=12)
    plt.title(f'{texts[0][lang]}:\n{ylabel} = f ( {xlabel} ){subtitle}', pad=15, fontsize=fontsize_title)
    plt.xlabel(xlabel, fontsize=fontsize_label)
    plt.ylabel(ylabel, fontsize=fontsize_label)

    plt.text(x_bound[0] + (x_bound[1] - x_bound[0]) * 0.4,
             y_bound[0] + (y_bound[1] - y_bound[0]) * 0.9,
             f'{texts[1][lang]}:\n{x_values.corr(df[y]):.4f}',
             rotation=0,
             fontsize=14,
             bbox={'facecolor': 'white', 'boxstyle': 'round', 'pad': 0.75, 'alpha': 0.5},
             )

    plt.show()


def print_corr(df, min_corr=0, figsize=None, fontsize_title=None, lang=None, **kwargs):
    """Feature correlation graph

Parameters
----------
df: pandas.DataFrame
    Input data table

min_corr: float, default=0
    The lower bound of the correlation coefficient to display on the graph

figsize: 2-tuple of floats, default=auto
    Figure dimension (width, height) in inches.

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

**kwargs:
    Properties, optional
    for sns.heatmap

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Correlation of features', 'RU': 'Корреляция признаков'},
        {'EN': 'Maximum detected correlation', 'RU': 'Максимальная выявленная корреляция'},
        {'EN': 'less than the specified', 'RU': 'меньше чем заданная'},
    ]
    
    max_corr = df.corr(numeric_only=True).abs().replace(1, 0).max()
    if max_corr.max() < min_corr:
        print(f'{texts[1][lang]}: \
{text.BOLD}{text.BG_SILVER} {df.corr(numeric_only=True).replace(1, 0).abs().max().max():.3f} {text.END} \
{texts[2][lang]}')
        return
    indexes = max_corr[max_corr > min_corr].index
    df_in = df[indexes].copy()
    
    if figsize is None:
        fig_side = df_in.select_dtypes(include='number').shape[1]
        figsize = (fig_side, fig_side * 0.6)
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    plt.figure(figsize=figsize)
    sns.heatmap(df_in.corr(numeric_only=True),
                annot=True, fmt='.2f', cmap='YlGnBu',
                mask=df_in.corr(numeric_only=True).abs() < min_corr,
                **kwargs)
    plt.title(texts[0][lang], pad=15, fontsize=fontsize_title)
    plt.show()
    print(f'{texts[1][lang]}: \
{text.BOLD}{text.BG_SILVER} {df.corr(numeric_only=True).replace(1, 0).abs().max().max():.3f} {text.END}')


def show_corr_target(data, target, subtitle='', figsize=None, fontsize_title=None, lang=None, **kwargs):
    """Show features correlation with target feature

Parameters
----------
data: pandas.DataFrame
    Input data table

target: str
    Name of the column with the target feature

figsize: 2-tuple of floats, default=(8, auto)
    Figure dimension (width, height) in inches.

subtitle: str, default=''
    Additional text in the title of the graph

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

**kwargs:
    Properties, optional
    for pd.plot.barh

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Correlation of features with the target feature',
         'RU': 'Корреляция признаков с целевым признаком'},
    ]
    
    if figsize is None:
        fig_side = data.shape[1]
        figsize = (10, fig_side * 10 / (fig_side + 10))
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    get_corr_target(data, target).sort_values('corr').plot(kind='barh', figsize=figsize, **kwargs)
    
    plt.grid(visible=True, axis='both', color='grey', linestyle=':')
    plt.title(f'{texts[0][lang]}{subtitle}', pad=15, fontsize=fontsize_title)
    plt.show()


def target_corr_binary(df, col, target, as_category=False, bins=50, ylabel=None,
                       subtitle='', figsize=(9, 9), fontsize_label=None, fontsize_title=None, lang=None, **kwargs):
    """Зависимость признака от целевого бинарного признака

Parameters
----------
df: pandas.DataFrame
    Input data table

col: str
    Name of the column with the feature under consideration

target: str
    The name of the column with the target feature

as_category: bool, default=False
    The feature in question is categorical

bins: int, default=50
    Number of histogram bins to be used

ylabel: str, default=None
    Y-Axis Label

subtitle: str, default=''
    Additional text in the title of the graph

figsize: 2-tuple of floats, default=(9, 9)
    Figure dimension (width, height) in inches.

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

**kwargs:
    Properties, optional
    for sns.histplot

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Distribution of the parameter', 'RU': 'Распределение показателя'},
        {'EN': 'depending on the target', 'RU': 'в зависимости от целевого признака'},
        {'EN': 'Count of values', 'RU': 'Кол-во значений'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    # df_in = df[[col, target]].copy()
    # Если оставлять в наборе только 2 признака, то hue не применить
    df_in = df.copy()
    if as_category:
        df_in[col] = df_in[col].astype('str')

    if ylabel is None:
        ylabel = description.get(col)

    fig, axs = plt.subplots(1, 2, sharey=True)
    plt.subplots_adjust(wspace=0, hspace=1)
    fig.set_figwidth(figsize[0])
    fig.set_figheight(figsize[1])
    fig.suptitle(f'{texts[0][lang]} "{ylabel}"{subtitle}\n {texts[1][lang]}', fontsize=fontsize_title)
    
    sns.histplot(ax=axs[0], data=df_in.loc[df_in[target] == 0], y=col, bins=bins,
                 color='tab:blue', label=f'{target} 0', **kwargs)  # element='step'
    sns.histplot(ax=axs[1], data=df_in.loc[df_in[target] == 1], y=col, bins=bins,
                 color='tab:orange', label=f'{target} 1', **kwargs)  # element='step'

    x_max = max([axs[0].get_xbound()[1], axs[1].get_xbound()[1]])
    y_min, y_max = axs[0].get_ybound()
    axs[0].axis([x_max, 0, y_min, y_max])
    axs[1].axis([0, x_max, y_min, y_max])

    for ax in axs:
        ax.grid(color='grey', linestyle=':')
        ax.spines['top'].set_visible(False)
        ax.set_xlabel(texts[2][lang], fontsize=fontsize_label)
        ax.tick_params(labelsize=12)
        ax.legend(fontsize=13, loc='best')
    axs[0].set_ylabel(ylabel, fontsize=fontsize_label)
    axs[1].spines['right'].set_visible(False)

    plt.show()


def target_corr_reg(df, col, target, as_category=False, xlabel=None, ylabel=None,
                    subtitle='', figsize=(9, 9), fontsize_label=None, fontsize_title=None, lang=None, **kwargs):
    """Dependence of the feature on the target regressive feature

Parameters
----------
df: pandas.DataFrame
    Input data table

col: str
    Name of the column with the feature under consideration

target: str
    The name of the column with the target feature

as_category: bool, default=False
    The feature in question is categorical

xlabel: str, default=None
    X-Axis Label (target feature)

ylabel: str, default=None
    Y-Axis Label

subtitle: str, default=''
    Additional text in the title of the graph

figsize: 2-tuple of floats, default=(9, 9)
    Figure dimension (width, height) in inches.

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

**kwargs:
    Properties, optional
    for sns.histplot

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Distribution of the target depending on the parameter',
         'RU': 'Распределение целевого признака в зависимости от показателя'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    if xlabel is None:
        xlabel = description.get(col)
        ylabel = description.get(target)

    title_label = xlabel
    reg_res = []

    # df_in = df[[col, target]].copy()
    # Если оставлять в наборе только 2 признака, то hue не применить
    df_in = df.copy()
    nunique = df_in[col].nunique()
    
    if as_category:
        df_in[col] = df_in[col].astype('str')
        x_axis, y_axis = target, col
        xlabel, ylabel = ylabel, xlabel
    else:
        x_axis, y_axis = col, target

    if nunique < 9 and figsize[1] == 9:
        if as_category:
            figsize = (figsize[0], nunique)
        else:
            figsize = (nunique, figsize[1])
    
    # Grouping for regression points:
    if as_category or nunique < 13:
        intervals = df_in[col]
    else:
        intervals = pd.to_numeric(pd.cut(df_in[col], 10).apply(lambda x: (x.left + x.right)*0.5))
    median_data = df_in.groupby(intervals)[target].median().reset_index()
    
    plt.figure(figsize=figsize)
    plt.grid(visible=True, axis='both', color='grey', linestyle=':')
    sns.histplot(data=df_in, x=x_axis, y=y_axis, **kwargs)
    # median points:
    sns.scatterplot(
        data=median_data,
        x=x_axis, y=y_axis,
        marker='o', color='indigo', alpha=0.5, s=max(figsize)*10,
        label='median values for groups'
    )

    # Regressions:
    if not as_category:
        # Regression functions
        reg_res = budin_math.get_reg_results(median_data[col], median_data[target])
        # Better regression:
        best_reg_func = reg_res.loc[reg_res['R2'].idxmax(), 'function']
        reg_func = budin_math.make_function(best_reg_func)
        # xs = sorted(df_in[col].dropna().unique())[1:-1]
        reg_data = df_in[[col]].drop_duplicates().dropna()
        reg_data['y'] = reg_func(reg_data[col])
        y_bound = min(df_in[target]), max(df_in[target])
        reg_data = reg_data[reg_data['y'].between(*y_bound)]
        sns.lineplot(
            data=reg_data,
            x=col,
            y='y',
            linestyle='--', linewidth=2, color='coral',
            label=best_reg_func
        )

    plt.title(f'{texts[0][lang]}\n"{title_label}"\n{subtitle}', pad=15, fontsize=fontsize_title)
    plt.xlabel(xlabel, fontsize=fontsize_label)
    plt.ylabel(ylabel, fontsize=fontsize_label)
    plt.tick_params(labelsize=12)

    plt.show()
    # All regressions:
    if not as_category:
        display(reg_res)


def gaussian_distribution(data, required_score, name='some values',
                          fontsize_label=None, fontsize_title=None, lang=None, figsize=(10, 8)):
    """Normal distribution and probability of loss is less than `required_score`

Parameters
----------
data: pandas.DataFrame or numpy.array
    Variation series

required_score: numeric
    The threshold value in question

name: str, default='some values'
    Name of the parameter under consideration

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

figsize: 2-tuple of floats, default=(10, 8)
    Figure dimension (width, height) in inches.

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Normal \ndistribution', 'RU': 'Нормальное \nраспределение'},
        {'EN': 'Probabilities', 'RU': 'Вероятности'},
        {'EN': 'Desired \nvalue', 'RU': 'Искомое \nзначение'},
        {'EN': 'Values for', 'RU': 'Значения для'},
        {'EN': 'Frequency for normal distribution', 'RU': 'Частота для нормального распределения'},
        {'EN': 'Probability of value greater than given', 'RU': 'Вероятность значения больше данного'},
        {'EN': 'Normal distribution', 'RU': 'Нормальное распределение'},
        {'EN': 'set of', 'RU': 'набор из'},
        {'EN': 'values', 'RU': 'значений'},
        {'EN': 'The probability\nless than needed', 'RU': 'Вероятность меньше\nискомого'},
        {'EN': 'Average', 'RU': 'Среднее'},
        {'EN': 'Rejection', 'RU': 'Отклонение'},
        {'EN': 'The probability of getting a value is less', 'RU': 'Вероятность получить значение меньше'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    # Normal distribution
    mu = data.mean()
    sigma = np.std(data, ddof=1)

    x = [i / 1000 for i in range(int((mu - 4 * sigma) * 1000), int((mu + 4 * sigma) * 1000))]
    distr = st.norm(mu, sigma)

    # Plotting
    fig, ax1 = plt.subplots()
    ax2 = ax1.twinx()
    ax1.plot(x, distr.pdf(x), label=texts[0][lang], color='r', linewidth=4)
    ax2.plot(x, distr.cdf(x), label=texts[1][lang], color='b', linestyle='--', linewidth=2)
    ax2.plot([required_score, required_score], [0, 1], label=texts[2][lang], linestyle=':', color='g', linewidth=4)

    fig.set_figwidth(figsize[0])
    fig.set_figheight(figsize[1])

    ax1.minorticks_on()
    ax1.grid(which='major',
             color='grey',
             linewidth=1.2)
    ax1.grid(which='minor',
             color='grey',
             linestyle=':')

    ax1.legend(fontsize=12, loc='center left')
    ax2.legend(fontsize=12, loc='center right')

    ax1.set_xlabel(f'{texts[3][lang]} {name}', fontsize=fontsize_label)
    ax1.set_ylabel(texts[4][lang], fontsize=fontsize_label)
    ax2.set_ylabel(texts[5][lang], fontsize=fontsize_label)
    ax1.tick_params(labelsize=12)
    ax2.tick_params(labelsize=12)
    ax1.set_title(f'{texts[6][lang]} {name}\n({texts[7][lang]} {data.shape[0]} {texts[8][lang]})', pad=15,
                  fontsize=fontsize_title)

    ax2.text(mu - 4 * sigma, 0.85, f'{texts[9][lang]} {required_score}:\n{distr.cdf(required_score):.3%}',
             rotation=0,
             fontsize=min(figsize) * 1.75,
             bbox={'facecolor': 'white', 'pad': min(figsize)}
             )
    ax2.text(mu - 4 * sigma, 0.3, f'{texts[10][lang]} = {mu:.4f}\n{texts[11][lang]} = {sigma:.4f}',
             rotation=0,
             fontsize=min(figsize) * 1.5,
             bbox={'facecolor': 'white', 'pad': min(figsize)}
             )
    plt.show()
    print('-' * options.TABLE_SIZE)
    print(f'\x1b[1m{texts[12][lang]} {required_score} = \x1b[43m {distr.cdf(required_score):.3%} \x1b[49m\x1b[22m')
    print('-' * options.TABLE_SIZE)
    print()
