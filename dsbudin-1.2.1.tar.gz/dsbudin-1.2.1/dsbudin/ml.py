from dsbudin.formattext import text
import time
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from copy import deepcopy

from sklearn.pipeline import Pipeline
from sklearn.compose import make_column_selector
from sklearn.preprocessing import OrdinalEncoder
from sklearn.inspection import permutation_importance
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import roc_auc_score, roc_curve


class Options:
    """Module settings:
    
Attributes
----------

TABLE_SIZE = 100
    Horizontal lines width

FONTSIZE_LABEL = 14
    Font size for axis labels

FONTSIZE_TITLE = 16
    Font size for graph names

LANG = 'EN'
    The language of the output text: 'RU' or 'EN'
    """
    TABLE_SIZE = 100
    FONTSIZE_LABEL = 14
    FONTSIZE_TITLE = 16
    LANG = 'EN'

    def __repr__(self):
        return f'TABLE_SIZE = {self.TABLE_SIZE}\n\
FONTSIZE_LABEL = {self.FONTSIZE_LABEL}\n\
FONTSIZE_TITLE = {self.FONTSIZE_TITLE}\n\
LANG = {self.LANG}\n\
'


options = Options()


def xy_split(data, target_column):
    """Target Feature Selection:

Parameters
----------
data: pandas.DataFrame
    Input data table

target_column: str
    Name of the column with the target feature

Returns
-------
X: pandas.DataFrame
    The training input samples

y: pandas.Series
    The target values 
"""
    return data.drop(columns=[target_column], axis=1), data[target_column]


def research_test_split(df, *, test_size=0.2, test_index=None, random_state=None, lang=None):
    """Breakdown into validation and test samples (with display of the ratio)

Parameters
----------
df: pandas.DataFrame
    Input data table

test_size: float or int, default=0.2
    If `float`, should be between 0.0 and 1.0 and represent the proportion of the dataset to include in the test split.
    If int, represents the absolute number of test samples.

test_index: list or Index, default = []
    Indexes of objects required to be included in the test set

random_state: int, RandomState instance, default=None
    Controls the randomness

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

Returns
-------
splitting: list, length=2 * len(arrays)
    List containing train-test split of inputs:
    df_research, df_test
"""
    texts = [
        {'EN': 'Sample', 'RU': 'Выборка'},
        {'EN': 'Research', 'RU': 'Исследовательская'},
        {'EN': 'Test', 'RU': 'Тестовая'},
        {'EN': 'Count of values', 'RU': 'Количество значений'},
        {'EN': 'Sample share', 'RU': 'Доля выборки'},
    ]
    if test_index is None:
        test_index = []
    if lang is None:
        lang = options.LANG
    
    lensubtest = len(test_index)
    if isinstance(test_size, float):
        test_size = (test_size * df.shape[0] - lensubtest) / (df.shape[0] - lensubtest)
    else:
        test_size -= lensubtest
     
    df_research, df_test = train_test_split(df.drop(test_index), test_size=test_size, random_state=random_state)
    df_test = pd.concat([df_test, df.loc[test_index]])
    print()
    display(pd.DataFrame({
        texts[0][lang]: [texts[1][lang], texts[2][lang]],
        texts[3][lang]: [df_research.shape[0], df_test.shape[0]],
        texts[4][lang]: [df_research.shape[0] / df.shape[0], df_test.shape[0] / df.shape[0]]
    }).style.format({texts[3][lang]: '{:.0f}', texts[4][lang]: '{:.2%}'})
            )
    return df_research, df_test


def rename_pipeline_params(params_pipeline):
    """Renaming the pipeline parameters: removes "model__" from the results of selecting hyperparameters

Parameters
----------
params_pipeline: dict
    Result of selection of hyperparameters like: {'model_hyper_parameter': value, ...}

Returns
-------
renamed_params: dict
    Changed result of selection of hyperparameters like: {'hyper_parameter': value, ...}
"""
    result = {}
    for p, val in params_pipeline.items():
        param = p.split('__')[1]
        result[param] = val
    return result


def cross_val_base(model_name, estimator, x, y, scoring, cv=10, print_res=True, lang=None):
    """Cross-validation with result for one model

Parameters
----------
model_name: str
    Model name used in the resulting table

estimator: estimator object implementing ‘fit’
    The object to use to fit the data.

x: pandas.DataFrame
    The training input samples

y: array-like
    The target values 

scoring: str or callable
    A str (https://scikit-learn.org/stable/modules/model_evaluation.html)
    or a scorer callable object / function with signature scorer(estimator, X, y)
    which should return only a single value.

cv: int, default=10
    Determines the cross-validation splitting strategy.

print_res: bool, default=True
    Display the result

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

Returns
-------
model_name: str
    Model name used in the resulting table

mean_score: float
    Mean score value

time_learn: float
    Cross-validation time in seconds

"""
    texts = [
        {'EN': 'The average value of the', 'RU': 'Среднее значение метрики'},
        {'EN': 'metric for the base model', 'RU': 'для базовой модели'},
    ]
    if lang is None:
        lang = options.LANG
    
    time_start = time.time()
    scores = cross_val_score(estimator, x, y, scoring=scoring, cv=cv)
    if print_res:
        print(
            f'{texts[0][lang]} {scoring} {texts[1][lang]} {text.BOLD}{model_name}\
:\n{text.BG_SILVER} {scoring} = {scores.mean():.2f} {text.END}')
        print('-' * options.TABLE_SIZE)
        return
    return model_name, scores.mean(), time.time() - time_start


def get_selection_model_results(results, score_name='Score'):
    """Displays a table comparing cross-validation results for the `ml.cross_val_base' function

Parameters
----------
results: list
    Multiple cross-validation results for the `ml.cross_val_base` function in the form of a list

score_name: str, default='Score'
    Name of the metric to display in the summary table

Returns
-------
res: pd.DataFrame
    Cross-validation results comparison table for `ml.cross_val_base' function

Sample
------
#Example of `results`
results = []
results.append(
    ml.cross_val_base('LogisticRegression',
                      LogisticRegression(**std_param, max_iter=500),
                      X, y,
                      scoring,
                      print_res=False)
)
"""
    res = pd.DataFrame(results, columns=['Model', score_name, 'Time']).sort_values(by=score_name, ascending=False)

    res['rating_score'] = res.apply(
        lambda row: round((row[score_name] - res[score_name].min()) / (res[score_name].max() - res[score_name].min()),
                          3),
        axis=1)
    res['rating_time'] = res.apply(
        lambda row: round(-(row['Time'] - res['Time'].min()) / (res['Time'].max() - res['Time'].min()), 3),
        axis=1)
    res['rating_total'] = res['rating_score'] + res['rating_time']

    return res


def get_research_test_m_ohe(df, *, drop_first=True, test_size=0.2, test_index=None, random_state=None):
    """Direct feature encoding with the creation of a working feature set

Parameters
----------
df: pandas.DataFrame
    Input data table

drop_first: bool, default=True
    Whether to get k-1 dummies out of k categorical levels by removing the first level.

test_size: float or int, default=0.2
    If `float`, should be between 0.0 and 1.0 and represent the proportion of the dataset to include in the test split.
    If int, represents the absolute number of test samples.

test_index: list or Index, default = []
    Indexes of objects required to be included in the test set

random_state: int, RandomState instance, default=None
    Controls the randomness

Returns
-------
splitting: list, length=2 * len(arrays)
    List containing train-test split of inputs:
    df_research, df_test
"""
    df_major_ohe = pd.get_dummies(df, drop_first=drop_first)
    return research_test_split(df_major_ohe, test_size=test_size, test_index=test_index, random_state=random_state)


def get_research_test_m_oe(df, *,  test_size=0.2, test_index=None, random_state=None):
    """Sequential coding
The input is pandas.dataframe with features that need to be encoded with the 'category' type

Parameters
----------
df: pandas.DataFrame
    Input data table

test_size: float or int, default=0.2
    If `float`, should be between 0.0 and 1.0 and represent the proportion of the dataset to include in the test split.
    If int, represents the absolute number of test samples.

test_index: list or Index, default = []
    Indexes of objects required to be included in the test set

random_state: int, RandomState instance, default=None
    Controls the randomness

Returns
-------
splitting: list, length=2 * len(arrays)
    List containing train-test split of inputs:
    df_research, df_test
"""
    # через ColumnTransformer получается array без подписей с перемешанными колонками, поэтому так удобнее:
    encoder = OrdinalEncoder()
    df_major_oe = df.copy()
    df_major_oe[make_column_selector(dtype_include='category')] = encoder.fit_transform(
        df[make_column_selector(dtype_include='category')])

    return research_test_split(df_major_oe, test_size=test_size, test_index=test_index, random_state=random_state)


def get_important_columns(estimator, x, y, scoring, n_repeats=30, random_state=None):
    """Assessment of the importance of features

Parameters
----------
estimator: estimator object implementing ‘fit’
    The object to use to fit the data.

x: pandas.DataFrame
    The training input samples

y: array-like
    The target values 

scoring: str or callable
    A str (https://scikit-learn.org/stable/modules/model_evaluation.html)
    or a scorer callable object / function with signature scorer(estimator, X, y)
    which should return only a single value.

n_repeats: int, default=30
    Number of times to permute a feature.

random_state: int, RandomState instance, default=None
    Controls the randomness

Returns
-------
r: pd.Series
    Mean of feature importance +/- Standard deviation (over `n_repeats`)
"""
    estimator.fit(x, y)
    r = permutation_importance(estimator, x, y,
                               scoring=scoring,
                               n_repeats=n_repeats,
                               random_state=random_state)
    for i in r.importances_mean.argsort()[::-1]:
        if r.importances_mean[i] - 2 * r.importances_std[i] > 0:
            print(f"{x.columns[i]:<40}"
                  f"{r.importances_mean[i]:.6f}"
                  f" +/- {r.importances_std[i]:.6f}")
    return x.columns[r.importances_mean.argsort()[::-1]]


def print_predictions_type1(pred, y, figsize=(8, 8), fontsize_label=None, fontsize_title=None, lang=None):
    """Plot of comparison of predictions and fact

Parameters
----------
pred: array-like
    Estimated target values

y: array-like
    The target values 

figsize: 2-tuple of floats, default=(8, 8)
    Figure dimension (width, height) in inches.

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Ratio of predicted values and true values\nin the test sample',
         'RU': 'Соотношение значений предсказаний и истинных значений\nна тестовой выборке'},
        {'EN': 'True values', 'RU': 'Истинные значения'},
        {'EN': 'Predicted values', 'RU': 'Значения предсказаний'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    plt.figure(figsize=figsize)
    plt.grid(visible=True, axis='both')
    limits = [min(y.min(), pred.min()), max(y.max() * 1.05, pred.max() * 1.05)]
    plt.xlim(limits)
    plt.ylim(limits)
    plt.plot(y, pred, 'x', alpha=0.6)
    plt.plot([limits[0], limits[1]], [limits[0], limits[1]], linewidth=3, color='firebrick')
    plt.title(texts[0][lang], pad=15, fontsize=fontsize_title)
    plt.xlabel(texts[1][lang], fontsize=fontsize_label)
    plt.ylabel(texts[2][lang], fontsize=fontsize_label)
    plt.plot()


def print_predictions_type2(pred, y, *, func=None, figsize=(8, 8), fontsize_label=None, fontsize_title=None, lang=None):
    """Plot of prediction and fact deviations

Parameters
----------
pred: array-like
    Estimated target values

y: array-like
    The target values 

func: callable, fefault=(pred, y): pred - y
    Error calculation function

figsize: 2-tuple of floats, default=(8, 8)
    Figure dimension (width, height) in inches.

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Deviations of the predicted values from the true values\nin the test sample',
         'RU': 'Отклонения значений предсказаний от истинных значений\nна тестовой выборке'},
        {'EN': 'True values', 'RU': 'Истинные значения'},
        {'EN': 'Predicted values', 'RU': 'Значения предсказаний'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    if func is None:
        def func(xf, yf): return xf-yf

    plt.figure(figsize=figsize)
    plt.grid(visible=True, axis='both')
    plt.plot(y, func(pred, y), 'x', alpha=0.6)
    plt.plot(np.zeros(int(y.max())), linewidth=3, color='firebrick')
    plt.title(texts[0][lang], pad=15, fontsize=fontsize_title)
    plt.xlabel(texts[1][lang], fontsize=fontsize_label)
    plt.ylabel(texts[2][lang], fontsize=fontsize_label)
    plt.plot()


def print_roc_curve(probabilities_one_test, target,
                    subtitle='', figsize=(7, 7), fontsize_label=None, fontsize_title=None, **kwargs):
    """Drawing the roc_auc curve

Parameters
----------
probabilities_one_test: array-like
    Target scores

target: array-like
    The target values 

subtitle: str, default=''
    Additional text in the title of the graph

figsize: 2-tuple of floats, default=(7, 7)
    Figure dimension (width, height) in inches.

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

**kwargs:
    Properties, optional

Returns
-------
graph: None
    A graph is being built
"""
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    
    roc_auc = roc_auc_score(target, probabilities_one_test)

    fpr, tpr, thresholds = roc_curve(target, probabilities_one_test)

    plt.figure(figsize=(figsize[0], figsize[1]))
    plt.plot(fpr, tpr, linewidth=3, color='darkcyan', **kwargs)
    plt.fill_between(fpr, tpr, 0, color='darkcyan', alpha=0.15)

    # ROC curve of the random model (looks like a straight line)
    plt.plot([0, 1], [0, 1], linestyle='--', color='darkkhaki')

    plt.xlim([-0.015, 1.0])
    plt.ylim([0.0, 1.015])
    plt.xlabel("False Positive Rate", fontsize=fontsize_label)
    plt.ylabel("True Positive Rate", fontsize=fontsize_label)
    plt.title(f"ROC curve{subtitle}", pad=15, fontsize=fontsize_title)

    plt.text(0.4, 0.1, f'ROC_AUC:\n{roc_auc:.4f}',
             rotation=0,
             fontsize=min(figsize) * 1.8,
             bbox={'facecolor': 'white', 'boxstyle': 'round', 'pad': min(figsize) / 12}
             )
    plt.show()


def grid_search_cv(x, y, estimator, parameters, scoring=None, cv=5, plot=False):
    """Key results for `sklearn.model_selection.GridSearchCV`

Parameters
----------
x: pandas.DataFrame
    The training input samples

y: array-like
    The target values 

estimator: estimator object implementing ‘fit’
    The object to use to fit the data.

parameters: dict or list of dictionaries
    Dictionary with parameters names (str) as keys and lists of parameter settings to try as values,
    or a list of such dictionaries, in which case the grids spanned by each dictionary in the list are explored.
    This enables searching over any sequence of parameter settings.

scoring: str or callable
    A str (https://scikit-learn.org/stable/modules/model_evaluation.html)
    or a scorer callable object / function with signature scorer(estimator, X, y)
    which should return only a single value.

cv: int, default=5
    Determines the cross-validation splitting strategy.

plot: bool, default=False
    Verbosity

Returns
-------
result: dict
    'iterations': Number of iterations,
    'score': Mean cross-validated score of the best_estimator,
    'parameters': Parameter setting that gave the best results on the hold out data
"""
    verbose = (0, 3)[plot]
    gscv = GridSearchCV(estimator, parameters, scoring=scoring, cv=cv, n_jobs=-1, verbose=verbose)
    gscv.fit(x, y)
    results = {
        'iterations': len(gscv.cv_results_['params']),
        'score': gscv.best_score_,
        'parameters': gscv.best_params_
    }
    return results


def ascending_grid(x, y, estimator, parameters, scoring=None, max_tail=None, nround=5, cv=5,
                   random_state=None, plot=False, **kwargs):
    """Searching for and selecting hyperparameters for the training model
It does not pass through the entire grid, but while the value of the metric is growing (Bayesian optimization).
Works faster than GridSearchCV

Parameters
----------
x: pandas.DataFrame
    The training input samples

y: array-like
    The target values 

estimator: estimator object implementing ‘fit’
    The object to use to fit the data.

parameters: dict
    Dictionary with parameters names (str) as keys
    and 2-lists or 2-tuple of min parameter setting and step parameter setting
    Sample:
        parameters = {
            'min_samples_split': [2, 1],
            'min_samples_leaf': [1, 1],
            'n_estimators': [50, 10],
            'max_depth': [2, 1]}

scoring: str or callable
    A str (https://scikit-learn.org/stable/modules/model_evaluation.html)
    or a scorer callable object / function with signature scorer(estimator, X, y)
    which should return only a single value.

max_tail: int, default=None
    Number of forced steps after the metric peak is reached
    If the metric does not grow during the `max_tail` steps, the cycle ends

nround: int, default=5
    Precision in decimal places for cross-validation of comparison results

cv: int, default=5
    Determines the cross-validation splitting strategy.

random_state: int, RandomState instance, default=None
    Controls the randomness

plot: bool, default=False
    Display information about each iteration

**kwargs:
    Properties, optional

Returns
-------
result: dict
    'iterations': Number of iterations,
    'score': Mean cross-validated score of the best_estimator,
    'parameters': Parameter setting that gave the best results on the hold out data
"""
    # cv = 5
    # at value 5 results differ from results at value > 10 !
    # but the default cross_val_score is 5, so let's leave it at 5 by default
    steps = 100
    iterator = 0
    best_score = -1_000_000
    best_param = parameters
    tail = 0
    if max_tail is None:
        max_tail = 1 if 5 - len(parameters) < 1 else 5 - len(parameters)

    param = list(parameters.keys())[0]
    start = parameters[param][0]
    sep = parameters[param][1]

    if len(parameters) == 1:
        for p in np.arange(start, start + steps * sep, sep):
            set_param = {param: p}
            if type(estimator) == Pipeline:
                model = estimator
                model_name = model.get_params().get("steps")[-1][0]
                # Hyper parameters (standard random_state=123, n_jobs=n_jobs are set externally):
                # Current Setting
                model.set_params(**{model_name + '__' + param: p})
                # **kwargs
                params_temp = {}
                for key, val in kwargs.items():
                    params_temp[model_name + '__' + key] = val
                model.set_params(**params_temp)
            else:
                model = estimator(random_state=random_state, **set_param, **kwargs)
            scores = cross_val_score(model, x, y, scoring=scoring, cv=cv)
            score = round(scores.mean(), nround)
            iterator += len(scores)
            if plot:
                # print(f'{p} >>> {set_param} {kwargs} - {score:.4f}')
                print(f'{p} >>> {set_param} {kwargs} - {score}')  # введен round: score = round(scores.mean(), nround)

            # if score > best_score:
            if (score - best_score) > 0.1**(nround+1):
                best_score = score
                set_param.update(kwargs)
                best_param = set_param
                tail = 0
            else:
                tail += 1
            if tail >= max_tail:
                break
    else:
        # рекурсия
        parameters_minus = deepcopy(parameters)
        del parameters_minus[param]
        for p in np.arange(start, start + steps * sep, sep):
            set_param = {param: p}
            result = ascending_grid(x, y, estimator, parameters_minus,
                                    scoring=scoring, max_tail=max_tail, nround=nround, cv=cv,
                                    random_state=random_state, plot=plot, **set_param, **kwargs)
            iterator += result['iterations']
            score = result['score']

            # Сокращение нижней границы поиска (предыдущее лучшее минус 2 промежутка)
            # Shrink lower search limit (previous best minus 2 gaps)
            for key in result['parameters'].keys():
                try:
                    new_start = result['parameters'][key] - parameters_minus[key][1] * 2
                    if parameters_minus[key][0] < new_start:
                        parameters_minus[key][0] = result['parameters'][key] - parameters_minus[key][1] * (max_tail + 1)
                except:
                    pass

            # if score > best_score:
            if (score - best_score) > 0.1**(nround+1):
                best_score = score
                best_param = result['parameters']
                tail = 0
            else:
                tail += 1
            if tail >= max_tail:
                break

        if plot:
            print('best_score =', best_score)
            print('best_param =', best_param)
    if plot:
        print('-' * options.TABLE_SIZE)
    return {'iterations': iterator, 'score': best_score, 'parameters': best_param}
