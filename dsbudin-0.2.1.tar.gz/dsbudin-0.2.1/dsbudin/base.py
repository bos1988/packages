from dsbudin.formattext import text
import pandas as pd
import numpy as np
from scipy import stats as st
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

TABLE_SIZE = 100
LANG = 'EN'
description = {}
# =====================================================================================================================
# Обработка:


# перевод из верблюжъего в змеиный регистр
def camel_to_snake(string, sep='_'):
    camel = ''
    for i in range(len(string)):
        camel += sep if string[i].isupper() and string[i-1].islower() else ''
        camel += string[i].lower()
    return camel.lstrip(sep)


# перевод из верблюжъего в змеиный регистр для словаря описания данных
def description_camel_to_snake(description_dict):
    camel_description = dict()
    for key, val in description_dict.items():
        camel_description[camel_to_snake(key)] = val
    return camel_description


# Преобразование признаков к типу данных category
def set_category_type(df, cat_features):
    df_cat = df.copy()
    df_cat[cat_features] = df_cat[cat_features].astype('category')
    return df_cat


# вывод больших чисел
def big_number(val):
    dec = str(round(val * 100 % 100))
    s = list(str(round(val)).lstrip('-'))
    for i in range(0, len(s)-1, 4):
        s.insert(-i-3, '`')
    return ('', '-')[int(val < 0)] + ''.join(s) + '.' + dec


# корреляция с целевым признаком
def get_corr(data, target):
    corrs = []
    for name in data.columns:
        corrs.append(data[name].corr(target))
    return pd.DataFrame({'name': data.columns, 'corr': corrs})

# =====================================================================================================================
# Информирование:


# вывод таблицы описания данных
def print_description(df):
    len_index = max([len(i) for i in df])
    for ind, name in enumerate(df):
        end = '' if len(description[name]) < TABLE_SIZE else '...'
        print(f'{str(ind).ljust(3)} {name.ljust(len_index)} - {description[name][:TABLE_SIZE]}{end}')


# общая информация об исходной таблице
def start_information(df, lang=LANG):
    texts = [
        {'EN': 'Indexes are', 'RU': 'Индексы'},
        {'EN': 'not ', 'RU': 'не '},
        {'EN': 'ordered', 'RU': 'упорядочены'},
        {'EN': 'Table size', 'RU': 'Размер таблицы'},
        {'EN': 'Target col', 'RU': 'Целевой признак'},
    ]
    result = []
    for col in df:
        result.append([
            col, df[col].count(), df[col].isna().sum(),
            df[col].dtype, df[col].nunique(), df[col].sample(10).values,
        ])
        if str(df[col].dtype)[:3] in 'intflo':
            result[-1].extend([df[col].min(), df[col].max()])
        else:
            result[-1].extend(['-', '-'])
        result[-1].append(description[col])

    res = pd.DataFrame(result, columns=['Name', 'Count', 'NA', 'Type', 'Unique', 'Sample', 'min', 'max', 'description']).set_index('Name')
    display(res)
    print(f'{texts[0][LANG]}{text.BOLD} {[texts[1][LANG], ""][df.index.is_monotonic_increasing]}{texts[2][LANG]}: {text.END}', end='')
    print(*df.index.to_list()[:10], '...', sep=',', end='\n\n')
    print(f'{texts[3][LANG]}: {text.BOLD} {df.shape} {text.END}')
    print(f'{texts[4][LANG]}: {text.BOLD} {TARGET_COL} {text.END}')


# Вывод информации о всех таблицах:
def display_all(df, names, functions, divider=False, lang=LANG):
    texts = [
        {'EN': ' TABLE ', 'RU': ' ТАБЛИЦА '},
    ]
    size = TABLE_SIZE
    for name in names:
        if divider:
            print('_'*size)
        table_name = texts[0][LANG] + name + ' '
        print(text.BOLD, text.BG_SILVER, table_name + table_name.rjust(size-len(table_name)-2, '='), text.END)
        if type(functions) == str:
            display(eval(f"df['{name}'].{functions}"))
        else:
            for func in functions:
                print(text.BOLD, end='')
                print('.'*size)
                print(func.rjust(size))
                print(text.END, end='')
                display(eval(f"df['{name}'].{func}"))
        print()


# остаток данных
def show_remains(data, original_shape, lang=LANG):
    texts = [
        {'EN': 'remains', 'RU': 'остаток'},
        {'EN': 'Rows', 'RU': 'Строк'},
        {'EN': 'Columns', 'RU': 'Столбцов'},
    ]
    display((pd.DataFrame(data.shape, columns=[texts[0][LANG]]).T / original_shape).rename(columns={0: texts[1][LANG], 1: texts[2][LANG]}).style.format({texts[1][LANG]: '{:.1%}', texts[2][LANG]: '{:.1%}'}))


# проверка пропусков
def na_info(df, level=0.01, lang=LANG):
    texts = [
        {'EN': 'No omissions', 'RU': 'Нет пропусков:'},
        {'EN': 'There are omissions in all objects', 'RU': 'Во всех объектах имеются пропуски'},
        {'EN': 'Small percentage of omissions:', 'RU': 'Малая доля пропусков:'},
        {'EN': 'Estimation of the remainder (when deleting omissions with a small percentage):', 'RU': 'Оценка остатка (при удалении пропусков с малой долей):'},
        {'EN': 'No omissions with a small percentage', 'RU': 'Нет пропусков с малой долей'},
        {'EN': 'A large percentage of omissions:', 'RU': 'Большая доля пропусков:'},
        {'EN': 'There are no omissions with a large percentage', 'RU': 'Нет пропусков с большой долей'},
    ]
    sum_table = df.isna().sum()
    na_table = df.count()
    res_table = pd.DataFrame([na_table, sum_table, sum_table / na_table]).T.rename(columns={0: 'count', 1: 'na', 2: 'fraction'})
    res_table[['count', 'na']] = res_table[['count', 'na']].astype('int')

    # Нет пропусков
    print(text.BOLD, text.BG_SILVER, texts[0][LANG].ljust(TABLE_SIZE, ' '), text.END)
    if res_table.query('na == 0').shape[0] > 0:
        display(res_table.query('na == 0').style.format({'fraction': '{:.2%}'}))
    else:
        print(f'\n {text.RED}{text.BOLD} {texts[1][LANG]} {text.END}')
    print()

    # Малая доля (на удаление)
    print(text.BOLD, text.BG_SILVER, texts[2][LANG].ljust(TABLE_SIZE, ' '), text.END)
    small = res_table.query('fraction < @level and na > 0')
    if small.shape[0] > 0:
        display(small.style.format({'fraction': '{:.2%}'}))
        remains = df[res_table.query('fraction < @level and na > 0').index].dropna().shape[0] / df.shape[0]
        print(f'{texts[3][LANG]} {text.BOLD}{text.BG_YELLOW} {remains:.3%} {text.END}')
    else:
        print(f'\n {text.GREEN}{text.BOLD} {texts[4][LANG]} {text.END}')
    print()

    # Большая доля (на обработку)
    print(text.BOLD, text.BG_SILVER, texts[5][LANG].ljust(TABLE_SIZE, ' '), text.END)
    big = res_table.query('fraction > @level')
    if big.shape[0] > 0:
        display(big.style.format({'fraction': '{:.2%}'}))
    else:
        print(f'\n {text.GREEN}{text.BOLD} {texts[6][LANG]} {text.END}')

    return {'delete': list(small.index), 'process': list(big.index)}

# =====================================================================================================================
# Презентации:


# Обзор категориальных признаков
def category_overview(df, col, pie=True, lang=LANG):
    texts = [
        {'EN': 'Count of unique values', 'RU': 'Количество уникальных значений'},
        {'EN': 'Count of values', 'RU': 'Кол-во значений'},
        {'EN': 'Percentage of distribution', 'RU': 'Процент распределения'},
        {'EN': 'Volumes of values for parameter', 'RU': 'Объемы значений показателя'},
    ]
    print(f'{texts[0][LANG]} {text.BOLD}{text.BG_SILVER} {df[col].nunique()} {text.END} :')
    display(
        pd.concat([df[col].value_counts(dropna=False).rename(texts[1][LANG]), df[col].value_counts(dropna=False, normalize=True).rename(texts[2][LANG])], axis=1)
        .style.format({texts[2][LANG]: '{:.2%}'})
    )
    if pie:
        print('-'*TABLE_SIZE)
        df[col].value_counts(dropna=False).plot.pie(figsize=(6, 6), fontsize=12)
        plt.title(f'{texts[3][LANG]}\n {description[col]}', pad=15, fontsize=16)
        plt.ylabel('')
        plt.tick_params(labelsize=18)


# Гистограмма с боксплотом
def hist_box_describe(df, col, subtitle='', xlabel=None, data=None, bins=None, figsize=(8, 8), lang=LANG, **kwargs):
    texts = [
        {'EN': 'Count of values', 'RU': 'Количество значений'},
        {'EN': 'Distribution for parameter', 'RU': 'Распределение показателя'},
    ]
    if type(data) == type(None):
        data = df[col]
    if xlabel is None:
        try:
            xlabel = description[col]
        except:
            pass
    if bins is None:
        bins = data.nunique()

    fig = plt.figure()

    # Разделение fig на зоны разных размеров:
    gs1 = GridSpec(5, 1, left=0.05, right=0.95, hspace=0.03)
    # (y, x) - размеры сетки (высота, ширина)
    # left - расположние левой границы всей сетки (топа margin)
    # right - расположние правой границы всей сетки (топа margin)
    # wspace, hspace - зазоры между графиками (вертикальный, горизонтальный)
    ax1 = fig.add_subplot(gs1[:1, :])  # (срез по Y, срез по X)
    ax2 = fig.add_subplot(gs1[1:, :])

    # Построение графиков:
    data.plot(ax=ax1, kind='box', vert=False, widths=0.6, **kwargs)
    data.plot(ax=ax2, kind='hist', grid=True, bins=bins, **kwargs)

    # Различные настройки графиков:
    fig.set_figwidth(figsize[0])
    fig.set_figheight(figsize[1])
    # fig.suptitle(f'Распределение показателя "{xlabel}"', fontsize = 16)

    ax1.xaxis.tick_top()
    ax2.minorticks_on()
    ax2.grid(which='major',
            color='grey',
            linewidth=1.2)
    ax2.grid(which='minor',
            color='grey',
            linestyle=':')

    ax1.set_yticklabels([''])
    ax2.set_xlabel(xlabel, fontsize=14)
    ax2.set_ylabel(texts[0][LANG], fontsize=14)
    ax1.tick_params(labelsize=12)
    ax2.tick_params(labelsize=12)
    ax1.set_title(f'{texts[1][LANG]} "{xlabel}"{subtitle}', pad=15, fontsize=16)

    x = ax2.get_xbound()
    y = ax2.get_ybound()
    x_coord = x[0] + (x[1]-x[0])/figsize[0]*figsize[1]*0.03 if data.mean() < data.quantile(0.5) else x[1] - (x[1]-x[0])/figsize[0]*figsize[1]*0.36
    y_coord = y[1] - (y[1]-y[0])*0.35
    ax2.text(x_coord, y_coord, str(data.describe()),
        rotation=0,
        fontsize=figsize[1]*1.2,
        bbox={'facecolor': 'white', 'boxstyle': 'round', 'pad': 1}
            )


# Гистограмма с боксплотом для временного ряда
def date_hist_describe(df, col, subtitle='', xlabel=None, data=None, bins=100, figsize=(12, 6), lang=LANG, **kwargs):
    texts = [
        {'EN': 'Distribution of the count of values on the timeline', 'RU': 'Распределение количества значений по временной шкале'},
        {'EN': 'Count of values', 'RU': 'Кол-во значений'},
        {'EN': 'General information on the date scale', 'RU': 'Общая информация по шкале дат'},
        {'EN': 'The data is arranged in chronological order', 'RU': 'Данные упорядочены в хронологическом порядке'},
        {'EN': 'Dates are not ordered', 'RU': 'Даты не упорядочены'},
    ]
    if type(data) == type(None):
        data = df[col]
    if xlabel is None:
        try:
            xlabel = description[col]
        except:
            pass

    plt.figure(figsize=figsize)
    data.hist(bins=bins, **kwargs)

    plt.title(f'{texts[0][LANG]}\n({xlabel}){subtitle}', pad=15, fontsize=16)
    plt.xlabel(xlabel, fontsize=14)
    plt.ylabel(texts[1][LANG], fontsize=14)

    plt.show()
    print(f'{text.BOLD}{text.BG_SILVER} {texts[2][LANG]}: ', text.END)
    display(data.describe())

    print(text.BOLD, text.BG_SILVER)
    if data.is_monotonic:
        print(texts[3][LANG])
    else:
        print(texts[4][LANG])
    print(text.END)


# Многослойная гистограмма с боксплотом
def u_hist_box_describe(data, xlabel, *,
                         subtitle='', describe=True, lang=LANG,
                         bins=50, figsize=(10, 10), **kwargs):
    texts = [
        {'EN': 'Count of values', 'RU': 'Количество значений'},
        {'EN': 'Distribution for parameter', 'RU': 'Распределение показателя'},
    ]
    fig = plt.figure()

    count = len(data.columns)

    # Разделение fig на зоны разных размеров:
    gs1 = GridSpec(7+count, 1, left=0.05, right=0.95, hspace=0.03)
    # (y, x) - размеры сетки (высота, ширина)
    # left - расположние левой границы всей сетки (топа margin)
    # right - расположние правой границы всей сетки (топа margin)
    # wspace, hspace - зазоры между графиками (вертикальный, горизонтальный)
    ax = ['']*(count+1)
    ax[count] = fig.add_subplot(gs1[count:, :])
    for i in range(count):
        ax[i] = fig.add_subplot(gs1[i:i+1, :], sharex=ax[-1])

    # Построение графиков:
    color = ['darkcyan', 'darkorchid', 'gold', 'firebrick', 'royalblue']
    color_back = [(0/255, 139/255, 139/255, 0.2),
                  (153/255, 50/255, 204/255, 0.2),
                  (255/255, 215/255, 0/255, 0.2),
                  (178/255, 34/255, 34/255, 0.2),
                  (65/255, 105/255, 225/255, 0.2)]  # а больше пяти нецелесообразно, будет сливаться все
    i = 0
    for col in data.columns:
        data[col].plot(ax=ax[i], kind='box', vert=False, widths=0.8, color='black', **kwargs)
        data[col].plot(ax=ax[-1], kind='hist', bins=bins, histtype='step', linewidth=2, alpha=0.6+0.4/count, color=color[i], **kwargs)
        data[col].plot(ax=ax[-1], kind='hist', bins=bins, alpha=1/2/count, color=color[i], label='', **kwargs)
        ax[i].set_facecolor(color_back[i])
        i += 1

    # Различные настройки графиков:
    fig.set_figwidth(figsize[0])
    fig.set_figheight(figsize[1])
    # fig.suptitle(f'Распределение показателя "{xlabel}"', fontsize = 16)

    ax[0].xaxis.tick_top()
    ax[-1].minorticks_on()
    ax[-1].grid(which='major',
            color='darkgrey',
            linewidth=1.2)
    ax[-1].grid(which='minor',
            color='darkgrey',
            linestyle=':')

    for i in range(count):
        ax[i].xaxis.tick_top()
        ax[i].tick_params(labelsize=6)
        ax[i].set_yticklabels([''])
        # ax[i].legend([label1], fontsize = 12, loc='upper right')
    ax[-1].set_xlabel(xlabel, fontsize=14)
    ax[-1].set_ylabel(texts[0][LANG], fontsize=14)
    ax[0].tick_params(labelsize=12)
    ax[-1].tick_params(labelsize=12)
    ax[0].set_title(f'{texts[1][LANG]} "{xlabel}"{subtitle}', pad=15, fontsize=16)
    ax[-1].legend(fontsize=14, loc='upper right')

    if describe:
        describe_data = data.describe().drop(['25%', '75%'])
        # display(describe_data)
        bit = 5 - len(str(round(data.mean()[0]//1)))
        x = ax[-1].get_xbound()
        y = ax[-1].get_ybound()
        ax[-1].set_ylim(y[0], y[1]*1.3)
        x_coord = x[0] + (x[1]-x[0])/figsize[0]*figsize[1]*0.03
        y_coord = y[1] - (y[1] - y[0])*0
        ax[-1].text(x_coord, y_coord, str(describe_data.round(bit)),
            rotation=0,
            fontsize=figsize[1]*1.0,
            bbox={'facecolor': (0.95, 0.95, 0.95, 0.9), 'boxstyle': 'round', 'pad': 0.6}
                )


# Корреляция признаков
def print_corr(df, lang=LANG):
    texts = [
        {'EN': 'Correlation of features', 'RU': 'Корреляция признаков'},
        {'EN': 'Maximum detected correlation', 'RU': 'Максимальная выявленная корреляция'},
    ]
    sns.heatmap(df.corr())
    plt.title(texts[0][LANG], pad=15, fontsize=14)
    plt.show()
    print(f'{texts[1][LANG]}: {text.BOLD}{text.BG_SILVER} {df.corr().replace(1, 0).abs().max().max():.3f} {text.END}')


# Зависимость от целевого бинарного признака
def target_corr_binary(df, col, target, as_category=False, subtitle='', xlabel=None, bins=50, figsize=(7, 7), lang=LANG, **kwargs):
    texts = [
        {'EN': 'Distribution of the parameter', 'RU': 'Распределение показателя'},
        {'EN': 'depending on the target', 'RU': 'в зависимости от целевого признака'},
        {'EN': 'Count of values', 'RU': 'Кол-во значений'},
    ]
    df_in = df[[col, target]].copy()
    if as_category:
        df_in[col] = df_in[col].astype('str')

    if xlabel is None:
        try:
            xlabel = description[col]
        except:
            pass

    fig, axs = plt.subplots(1, 2, sharey=True)
    plt.subplots_adjust(wspace=0, hspace=1)
    fig.set_figwidth(figsize[0])
    fig.set_figheight(figsize[1])
    fig.suptitle(f'{texts[0][LANG]} "{xlabel}"{subtitle}\n {texts[1][LANG]}', fontsize=16)

    sns.histplot(ax=axs[0], data=df_in.query(f'{target}==0'), y=col, bins=bins, color='tab:blue', label=f'{target} 0', **kwargs)  # element='step'
    sns.histplot(ax=axs[1], data=df_in.query(f'{target}==1'), y=col, bins=bins, color='tab:orange', label=f'{target} 1', **kwargs)  # element='step'

    x_max = max([axs[0].get_xbound()[1], axs[1].get_xbound()[1]])
    y_min, y_max = axs[0].get_ybound()
    axs[0].axis([x_max, 0, y_min, y_max])
    axs[1].axis([0, x_max, y_min, y_max])

    for ax in axs:
        ax.grid(color='grey', linestyle=':')
        ax.spines['top'].set_visible(False)
        ax.set_xlabel(texts[2][LANG], fontsize=14)
        ax.tick_params(labelsize=12)
        ax.legend(fontsize=13, loc='best')
    axs[0].set_ylabel(xlabel, fontsize=14)
    axs[1].spines['right'].set_visible(False)

    plt.show()

# Зависимость от целевого регрессивного признака
def target_corr_reg(df, col, target, as_category=False, subtitle='', ylabel=None, tlabel=None, figsize=(8, 8), lang=LANG, **kwargs):
    texts = [
        {'EN': 'Distribution of the parameter', 'RU': 'Распределение показателя'},
        {'EN': 'depending on the target', 'RU': 'в зависимости от целевого признака'},
    ]
    df_in = df[[col, target]].copy()
    if as_category:
        df_in[col] = df_in[col].astype('str')

    if ylabel is None:
        try:
            ylabel = description[col]
            tlabel = description[target]
        except:
            pass

    if df_in[col].nunique() < 8 and figsize[1] == 8:
        figsize = (figsize[0], df_in[col].nunique())

    plt.figure(figsize=figsize)
    plt.grid(visible=True, axis='both', color='grey', linestyle=':')

    sns.histplot(data=df_in, x=target, y=col, **kwargs)

    plt.title(f'{texts[0][LANG]} "{ylabel}"{subtitle}\n {texts[1][LANG]}', pad=15, fontsize=16)
    plt.xlabel(tlabel, fontsize=14)
    plt.ylabel(ylabel, fontsize=14)
    plt.tick_params(labelsize=12)

    plt.show()


# Нормальное распределение и вероятность выпадения менее required_score
def gaussian_distribution(data, required_score, name='some values', lang=LANG, figsize=(10, 8)):
    texts = [
        {'EN': 'Normal \ndistribution', 'RU': 'Нормальное \nраспределение'},
        {'EN': 'Probabilities', 'RU': 'Вероятности'},
        {'EN': 'Desired \nvalue', 'RU': 'Искомое \nзначение'},
        {'EN': 'Values for', 'RU': 'Значения для'},
        {'EN': 'Frequency for normal distribution', 'RU': 'Частота для нормального распределения'},
        {'EN': 'Probability of value greater than given', 'RU': 'Вероятность значения больше данного'},
        {'EN': 'Normal distribution', 'RU': 'Нормальное распределение'},
        {'EN': 'set of', 'RU': 'набор из'},
        {'EN': 'values', 'RU': 'значений'},
        {'EN': 'The probability\nless than needed', 'RU': 'Вероятность меньше\nискомого'},
        {'EN': 'Average', 'RU': 'Среднее'},
        {'EN': 'Rejection', 'RU': 'Отклонение'},
        {'EN': 'The probability of getting a value is less', 'RU': 'Вероятность получить значение меньше'},
    ]
    # Нормальное распределение
    mu = data.mean()
    sigma = np.std(data, ddof=1)

    x = [i/1000 for i in range(int((mu - 4*sigma)*1000), int((mu + 4*sigma)*1000))]
    distr = st.norm(mu, sigma)

    # Построение графика
    fig, ax1 = plt.subplots()
    ax2 = ax1.twinx()
    ax1.plot(x, distr.pdf(x), label=texts[0][LANG], color='r', linewidth=4)
    ax2.plot(x, distr.cdf(x), label=texts[1][LANG], color='b', linestyle='--', linewidth=2)
    ax2.plot([required_score, required_score], [0, 1], label=texts[2][LANG], linestyle=':', color='g', linewidth=4)

    fig.set_figwidth(figsize[0])
    fig.set_figheight(figsize[1])

    # ax1.xaxis.tick_top()
    ax1.minorticks_on()
    ax1.grid(which='major',
            color='grey',
            linewidth=1.2)
    ax1.grid(which='minor',
            color='grey',
            linestyle=':')

    ax1.legend(fontsize=12, loc='center left')
    ax2.legend(fontsize=12, loc='center right')

    ax1.set_xlabel(f'{texts[3][LANG]} {name}', fontsize=14)
    ax1.set_ylabel(texts[4][LANG], fontsize=14)
    ax2.set_ylabel(texts[5][LANG], fontsize=14)
    ax1.tick_params(labelsize=12)
    ax2.tick_params(labelsize=12)
    ax1.set_title(f'{texts[6][LANG]} {name}\n({texts[7][LANG]} {data.shape[0]} {texts[8][LANG]})', pad=15, fontsize=16)

    ax2.text(mu - 4*sigma, 0.85, f'{texts[9][LANG]} {required_score}:\n{distr.cdf(required_score):.3%}',
            rotation=0,
            fontsize=min(figsize)*1.75,
            bbox={'facecolor': 'white', 'pad': min(figsize)}
                )
    ax2.text(mu - 4*sigma, 0.3, f'{texts[10][LANG]} = {mu:.4f}\n{texts[11][LANG]} = {sigma:.4f}',
            rotation=0,
            fontsize=min(figsize)*1.5,
            bbox={'facecolor': 'white', 'pad': min(figsize)}
                )
    plt.show()
    print('-'*TABLE_SIZE)
    print(f'\x1b[1m{texts[12][LANG]} {required_score} = \x1b[43m {distr.cdf(required_score):.3%} \x1b[49m\x1b[22m')
    print('-'*TABLE_SIZE)
    print()