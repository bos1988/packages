# ������ ������ ��� output
class text:
    END = '\x1b[0m'
    BOLD = '\x1b[1m'
    
    UNDERLINE = '\x1b[4m'
    
    NEGATIVE = '\x1b[7m'

    GREY = '\x1b[30m'
    RED = '\x1b[31m'
    GREEN = '\x1b[32m'
    YELLOW = '\x1b[33m'
    BLUE = '\x1b[34m'
    PURPLE = '\x1b[35m'
    CYAN = '\x1b[36m'
    SILVER = '\x1b[37m'
    BLACK = '\x1b[39m'
    
    BG_GREY = '\x1b[40m'
    BG_RED = '\x1b[41m'
    BG_GREEN = '\x1b[42m'
    BG_YELLOW = '\x1b[43m'
    BG_BLUE = '\x1b[44m'
    BG_PURPLE = '\x1b[45m'
    BG_CYAN = '\x1b[46m'
    BG_SILVER = '\x1b[47m'
    
    DARKGREY = '\x1b[90m'
    DARKRED = '\x1b[91m'
    DARKGREEN = '\x1b[92m'
    DARKYELLOW = '\x1b[93m'
    DARKBLUE = '\x1b[94m'
    DARKPURPLE = '\x1b[95m'
    DARKCYAN = '\x1b[96m'
    DARKSILVER = '\x1b[97m'
    
    BG_DARKGREY = '\x1b[100m'
    BG_DARKRED = '\x1b[101m'
    BG_DARKGREEN = '\x1b[102m'
    BG_DARKYELLOW = '\x1b[103m'
    BG_DARKBLUE = '\x1b[104m'
    BG_DARKPURPLE = '\x1b[105m'
    BG_DARKCYAN = '\x1b[106m'
    BG_DARKSILVER = '\x1b[107m'
    
    END_B = '\x1b[21m'
    END_U = '\x1b[24m'
    END_NEGATIVE = '\x1b[27m'
    END_C = '\x1b[39m'
    END_BG = '\x1b[49m'

# ������:
if __name__ == "__main__":
    print(text.UNDERLINE + text.BG_YELLOW + text.BLUE + text.BOLD + ' TEST TEXT ' + text.END_BG + text.END_B + ' TEXT ' + text.END + ' TEXT ')

    print(*[('TEST ' + getattr(text, i) + ' TEXT' + text.END + ' - ' + i) for i in text.__dict__ if not i.startswith('_') and not i.startswith('END')], sep='\n')
    print(*[text.UNDERLINE + text.BG_SILVER + text.RED + text.BOLD + 'TEST ' + (getattr(text, i) + ' TEXT' + text.END + ' - ' + i) for i in text.__dict__ if i.startswith('END')], sep='\n')
    input()
