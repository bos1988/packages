# The setup.py file should be used only when custom scripting during the build is necessary.
# Note that you can still keep most of configuration declarative in setup.cfg or pyproject.toml and use setup.py only for the parts not supported in those files (e.g. C extensions).

# https://setuptools.pypa.io/en/latest/userguide/quickstart.html

from setuptools import setup, find_packages
import os

setup_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(setup_dir, 'requirements.txt'), 'r') as req_file:
    requirements = [line.strip() for line in req_file if line.strip()]

setup(name="dsbudin", # name лучше без нижних подчеркиваний, дефисов, пробелов - могут возникнуть проблемы !!! name должно быть таким же как папка с файлами
      version="0.2.1", # version = мажорный релиз (нарушается совместимость, новый функционал).минорный релиз (не нарушается совместимость, улучшения).багфикс (исправление ошибок)
      description="DS functions from Budin Oleg",
      author="Budin Oleg",
      author_email="bos1988@mail.ru",
      packages=find_packages(),
      install_requirements=requirements,
      include_package_data=True) #принять список дополнительно необходимых файлов (помимо питоновских) - requirements.txt

# Запаковка
# Terminal: python setup.py sdist
# sdist - универсальный установщик
# bdist - под конкретную платформу (например, Linux)

# Установка:
# cd dist
# pip install mypackage-0.1.0.tar.gz
# или:
# pip install .
# pip install -e . #в режиме разработки