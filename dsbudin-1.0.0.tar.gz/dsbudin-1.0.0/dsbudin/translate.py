from translate import Translator
from langdetect import detect


def translate(s: str):
    """Russian to English or English to Russian text translation

Parameters
----------
s: str
    Russian or English text

Returns
-------
trans: str
    English or Russian translation depending on the text at the input
    """
    langs = ['ru', 'en']
    from_l = detect(str(s))
    langs.remove(from_l)
    to_l = langs[0]
    return Translator(from_lang=from_l, to_lang=to_l).translate(s)
