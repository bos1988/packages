from dsbudin.formattext import text
import pandas as pd
import numpy as np
from scipy import stats as st
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import math


class Options:
    """Module settings:
    
Attributes
----------
TABLE_SIZE = 100
    Horizontal lines width

FONTSIZE_LABEL = 14
    Font size for axis labels

FONTSIZE_TITLE = 16
    Font size for graph names

LANG = 'EN'
    The language of the output text: 'RU' or 'EN'
    """
    TABLE_SIZE = 100
    FONTSIZE_LABEL = 14
    FONTSIZE_TITLE = 16
    LANG = 'EN'

    def __repr__(self):
        return f'TABLE_SIZE = {self.TABLE_SIZE}\n\
FONTSIZE_LABEL = {self.FONTSIZE_LABEL}\n\
FONTSIZE_TITLE = {self.FONTSIZE_TITLE}\n\
LANG = {self.LANG}\n\
'


options = Options()
description = {}


# ---------------------------------------------------------------------------------------------------------------------
# Processing:


def camel_to_snake(string, sep='_'):
    """Translation from camel to snake register

Parameters
----------
string: str
    Camel register text

sep: str, default='_'
    Camel register separator

Returns
-------
camel: str
    Text in Snake Register
"""
    camel = ''
    for i in range(len(string)):
        camel += sep if string[i].isupper() and string[i - 1].islower() else ''
        camel += string[i].lower()
    return camel.lstrip(sep)


def description_camel_to_snake(description_dict):
    """Translation of data Description Dictionary keys from Camel to Snake register

Parameters
----------
description_dict: dict
    Dictionary of data description with keys in Camel register

Returns
-------
camel_description: dict
    Dictionary of data description with keys in the Snake register
"""
    camel_description = dict()
    for key, val in description_dict.items():
        camel_description[camel_to_snake(key)] = val
    return camel_description


def set_category_type(df, cat_features):
    """Converting features to the category data type

Parameters
----------
df: pandas.DataFrame
    Input data table

cat_features: array-like
    Names of features to replace the type with a categorical one

Returns
-------
df_cat: pandas.DataFrame
    New table with established types of categorical features
"""
    df_cat = df.copy()
    df_cat[cat_features] = df_cat[cat_features].astype('category')
    return df_cat


def big_number(val):
    """Beautiful display of large numbers

Parameters
----------
val: numeric
    Number

Returns
-------
res: str
    Number of type str with apostrophes
"""
    dec = str(round(val * 100 % 100))
    s = list(str(round(val)).lstrip('-'))
    for i in range(0, len(s) - 1, 4):
        s.insert(-i - 3, '`')
    return ('', '-')[int(val < 0)] + ''.join(s) + '.' + dec


def get_corr(data, target):
    """Features correlation with target feature

Parameters
----------
data: pandas.DataFrame
    Input data table

target: str
    Name of the column with the target feature

Returns
-------
df_corr: pandas.DataFrame
    Correlation Coefficients table
"""
    corrs = []
    for name in data.columns:
        corrs.append(data[name].corr(target))
    return pd.DataFrame({'name': data.columns, 'corr': corrs})


# ---------------------------------------------------------------------------------------------------------------------
# Informing:


def print_description(df):
    """Data description output

Parameters
----------
df: pandas.DataFrame
    Input data table

Returns
-------
print: None
    Display data description dictionary
"""
    len_index = max([len(i) for i in df])
    for ind, name in enumerate(df):
        end = '' if len(description[name]) < options.TABLE_SIZE else '...'
        print(f'{str(ind).ljust(3)} {name.ljust(len_index)} - {description[name][:options.TABLE_SIZE]}{end}')


def start_information(df, lang=None):
    """General information about the data in the table

Parameters
----------
df: pandas.DataFrame
    Input data table

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

Returns
-------
print: None
    Displaying a general table of data information
"""
    texts = [
        {'EN': 'Indexes are', 'RU': 'Индексы'},
        {'EN': 'not ', 'RU': 'не '},
        {'EN': 'ordered', 'RU': 'упорядочены'},
        {'EN': 'Table size', 'RU': 'Размер таблицы'},
        # {'EN': 'Target column', 'RU': 'Целевой признак'},
    ]
    if lang is None:
        lang = options.LANG
    
    result = []
    for col in df:
        result.append([
            col, df[col].count(), df[col].isna().sum(),
            df[col].dtype, df[col].nunique(), df[col].sample(10).values,
        ])
        if str(df[col].dtype)[:3] in 'intflo':
            result[-1].extend([df[col].min(), df[col].max()])
        else:
            result[-1].extend(['-', '-'])
        result[-1].append(description[col])

    res = pd.DataFrame(result,
                       columns=['Name', 'Count', 'NA', 'Type', 'Unique', 'Sample', 'min', 'max', 'description']) \
        .set_index('Name')
    display(res)
    print(f'{texts[0][lang]}{text.BOLD} \
{[texts[1][lang], ""][df.index.is_monotonic_increasing]}{texts[2][lang]}: {text.END}', end='')
    print(*df.index.to_list()[:10], '...', sep=',', end='\n\n')
    print(f'{texts[3][lang]}: {text.BOLD} {df.shape} {text.END}')
    # print(f'{texts[4][lang]}: {text.BOLD} {options.TARGET_COL} {text.END}')


def display_all(df, names, functions, divider=False, lang=None):
    """Output of the specified information for all tables:

Parameters
----------
df: dict{str: pandas.DataFrame}
    Vocabulary with input tables

names: list
    List of names of the tables under consideration

functions: str or list
    Called methods. For example: 'info()' or ['head()', 'info()', 'nunique()']

divider: bool, default=False
    Display separator

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

Returns
-------
print: None
    Displaying information on tables
"""
    texts = [
        {'EN': ' TABLE ', 'RU': ' ТАБЛИЦА '},
    ]
    if lang is None:
        lang = options.LANG
    
    size = options.TABLE_SIZE
    for name in names:
        if divider:
            print('_' * size)
        table_name = texts[0][lang] + name + ' '
        print(text.BOLD, text.BG_SILVER, table_name + table_name.rjust(size - len(table_name) - 2, '='), text.END)
        if type(functions) == str:
            display(eval(f"df['{name}'].{functions}"))
        else:
            for func in functions:
                print(text.BOLD, end='')
                print('.' * size)
                print(func.rjust(size))
                print(text.END, end='')
                display(eval(f"df['{name}'].{func}"))
        print()


def show_remains(data, original_shape, lang=None):
    """Displays the remaining data

Parameters
----------
data: pandas.DataFrame
    Input data table

original_shape: 2-tuple
    Dimension of the original data frame

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

Returns
-------
print`: None
    Displaying the percentage of the remaining data in comparison with the source table
"""
    texts = [
        {'EN': 'remains', 'RU': 'остаток'},
        {'EN': 'Rows', 'RU': 'Строк'},
        {'EN': 'Columns', 'RU': 'Столбцов'},
    ]
    if lang is None:
        lang = options.LANG
    
    display((pd.DataFrame(data.shape, columns=[texts[0][lang]]).T / original_shape)
            .rename(columns={0: texts[1][lang], 1: texts[2][lang]})
            .style.format({texts[1][lang]: '{:.1%}', texts[2][lang]: '{:.1%}'}))


def na_info(df, level=0.01, lang=None):
    """Pass check

Parameters
----------
df: pandas.DataFrame
    Input data table

level: float, default=0.01
    The percentage of omissions accepted as small

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

Returns
-------
print: None
    Displays pass information

columns: dict
    'delete': A list of columns with a small percentage of omissions that can be deleted
    'process': A list of columns with a large proportion of omissions that need to be processed
"""
    texts = [
        {'EN': 'No omissions', 'RU': 'Нет пропусков:'},
        {'EN': 'There are omissions in all objects', 'RU': 'Во всех объектах имеются пропуски'},
        {'EN': 'Small percentage of omissions:', 'RU': 'Малая доля пропусков:'},
        {'EN': 'Estimation of the remainder (when deleting omissions with a small percentage):',
         'RU': 'Оценка остатка (при удалении пропусков с малой долей):'},
        {'EN': 'No omissions with a small percentage', 'RU': 'Нет пропусков с малой долей'},
        {'EN': 'A large percentage of omissions:', 'RU': 'Большая доля пропусков:'},
        {'EN': 'There are no omissions with a large percentage', 'RU': 'Нет пропусков с большой долей'},
    ]
    if lang is None:
        lang = options.LANG
    
    sum_table = df.isna().sum()
    na_table = df.count()
    res_table = pd.DataFrame([na_table, sum_table, sum_table / df.shape[0]]).T.rename(
        columns={0: 'count', 1: 'na', 2: 'fraction'})
    res_table[['count', 'na']] = res_table[['count', 'na']].astype('int')

    # No passes
    print(text.BOLD, text.BG_SILVER, texts[0][lang].ljust(options.TABLE_SIZE, ' '), text.END)
    if res_table.query('na == 0').shape[0] > 0:
        display(res_table.query('na == 0').style.format({'fraction': '{:.2%}'}))
    else:
        print(f'\n {text.RED}{text.BOLD} {texts[1][lang]} {text.END}')
    print()

    # Small fraction (for deletion)
    print(text.BOLD, text.BG_SILVER, texts[2][lang].ljust(options.TABLE_SIZE, ' '), text.END)
    small = res_table.query('fraction < @level and na > 0')
    if small.shape[0] > 0:
        display(small.style.format({'fraction': '{:.2%}'}))
        remains = df[res_table.query('fraction < @level and na > 0').index].dropna().shape[0] / df.shape[0]
        print(f'{texts[3][lang]} {text.BOLD}{text.BG_YELLOW} {remains:.3%} {text.END}')
    else:
        print(f'\n {text.GREEN}{text.BOLD} {texts[4][lang]} {text.END}')
    print()

    # Large share (for processing)
    print(text.BOLD, text.BG_SILVER, texts[5][lang].ljust(options.TABLE_SIZE, ' '), text.END)
    big = res_table.query('fraction > @level')
    if big.shape[0] > 0:
        display(big.style.format({'fraction': '{:.2%}'}))
    else:
        print(f'\n {text.GREEN}{text.BOLD} {texts[6][lang]} {text.END}')

    return {'delete': list(small.index), 'process': list(big.index)}


# ---------------------------------------------------------------------------------------------------------------------
# Presentations:


def category_overview(df, col, pie=True, figsize=(6, 6), fontsize_title=None, lang=None, **kwargs):
    """Overview of categorical features

Parameters
----------
df: pandas.DataFrame
    Input data table

col: str
    Name of the column with the feature under consideration

pie: bool, default=True
    Display Graph

figsize: 2-tuple of floats, default=(6, 6)
    Figure dimension (width, height) in inches.

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

**kwargs:
    Properties, optional

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Count of unique values', 'RU': 'Количество уникальных значений'},
        {'EN': 'Count of values', 'RU': 'Кол-во значений'},
        {'EN': 'Percentage of distribution', 'RU': 'Процент распределения'},
        {'EN': 'Volumes of values for parameter', 'RU': 'Объемы значений показателя'},
    ]
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    print(f'{texts[0][lang]} {text.BOLD}{text.BG_SILVER} {df[col].nunique()} {text.END} :')
    display(
        pd.concat(
            [df[col].value_counts(dropna=False).rename(texts[1][lang]),
             df[col].value_counts(dropna=False, normalize=True).rename(texts[2][lang])],
            axis=1)
        .style.format({texts[2][lang]: '{:.2%}'})
    )
    if pie:
        print('-' * options.TABLE_SIZE)
        df[col].value_counts(dropna=False).plot.pie(figsize=figsize, fontsize=12, **kwargs)
        plt.title(f'{texts[3][lang]}\n {description[col]}', pad=15, fontsize=fontsize_title)
        plt.ylabel('')
        plt.tick_params(labelsize=18)


def hist_box_describe(df, col, xlabel=None, data=None, bins=None, fdist=None, kwargdist=None,
                      subtitle='', figsize=(8, 8), fontsize_label=None, fontsize_title=None, lang=None, **kwargs):
    """Histogram with boxplot

Parameters
----------
df: pandas.DataFrame
    Input data table

col: str
    Name of the column with the feature under consideration

xlabel: str, default=None
    X-Axis Label

data: pandas.Series, default=None
    Table of input data in case you need to consider data not from df

bins: int, default=None
    Number of histogram bins to be used

fdist: Scipy Continuous distributions, default=None
    A function for plotting a distribution graph containing the `.pdf` method

kwargdist: dict, default=None
    Dictionary with arguments passed to the function for plotting the distribution

subtitle: str, default=''
    Additional text in the title of the graph

figsize: 2-tuple of floats, default=(8, 8)
    Figure dimension (width, height) in inches.

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

**kwargs:
    Properties, optional

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Count of values', 'RU': 'Количество значений'},
        {'EN': 'Distribution for parameter', 'RU': 'Распределение показателя'},
        {'EN': 'For significance levels greater than', 'RU': 'Для уровней значимости более'},
        {'EN': 'it is possible to reject the null hypothesis\n\
that the data are distributed according to the theoretical law under consideration',
         'RU': 'можно отвергать нулевую гипотезу, о том\n\
что данные распределены по рассматриваемому теоретическому закону'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    if data is None:
        data = df[col].dropna()  # ! remove NaN ! (with NaN error when plotting distributions)
    if xlabel is None:
        try:
            xlabel = description[col]
        except:
            pass
    if bins is None:
        bins = data.nunique()

    fig = plt.figure()

    # Разделение fig на зоны разных размеров:
    gs1 = GridSpec(5, 1, left=0.05, right=0.95, hspace=0.03)
    # (y, x) - размеры сетки (высота, ширина)
    # left - расположение левой границы всей сетки (топа margin)
    # right - расположение правой границы всей сетки (топа margin)
    # wspace, hspace - зазоры между графиками (вертикальный, горизонтальный)
    ax1 = fig.add_subplot(gs1[:1, :])  # (срез по Y, срез по X)
    ax2 = fig.add_subplot(gs1[1:, :])

    # Graphing
    # Boxplot and histogram
    data.plot(ax=ax1, kind='box', vert=False, widths=0.6)
    data.plot(ax=ax2, kind='hist', grid=True, bins=bins, **kwargs)

    # Theoretical distribution (if specified)
    alpha_fact = 0
    if not (fdist is None):
        if kwargdist is None:
            kwargdist = {'loc': np.mean(data), 'scale': np.std(data, ddof=0)}
        x_minmax = min(data), max(data)
        h = (x_minmax[1] - x_minmax[0]) / bins
        xs = np.linspace(*x_minmax, bins)
        # Theoretical frequencies
        ys = fdist.pdf(x=xs, **kwargdist) * len(data) * h
        # Actual frequencies:
        w_fact = np.histogram(data, bins)[0]
        # Сгладим неоправданно большое расхождение между малыми частотами по краям выборки:
        indexes = np.where(w_fact > len(data) / bins * 0.5)
        # The value of the observed statistical criterion:
        r = len(kwargdist)
        k = bins - r - 1
        u = ((np.histogram(data, bins)[0] - ys) ** 2 / ys)[indexes].sum()
        pvalue = st.chi2.cdf(u, k)
        # Significance criterion:
        alpha_fact = 1 - pvalue
        # Graph
        ax2.plot(xs, ys, '--', linewidth=2.5)

    # Various chart settings:
    fig.set_figwidth(figsize[0])
    fig.set_figheight(figsize[1])

    ax1.xaxis.tick_top()
    ax2.minorticks_on()
    ax2.grid(which='major',
             color='grey',
             linewidth=1.0)
    ax2.grid(which='minor',
             color='grey',
             linestyle=':',
             linewidth=0.8)

    ax1.set_yticklabels([''])
    ax2.set_xlabel(xlabel, fontsize=fontsize_label)
    ax2.set_ylabel(texts[0][lang], fontsize=fontsize_label)
    ax1.tick_params(labelsize=12)
    ax2.tick_params(labelsize=12)
    ax1.set_title(f'{texts[1][lang]} "{xlabel}"{subtitle}', pad=15, fontsize=fontsize_title)

    x = ax2.get_xbound()
    y = ax2.get_ybound()
    x_coord = x[0] + (x[1] - x[0]) / figsize[0] * figsize[1] * 0.03 if data.mean() < data.quantile(0.5) else x[1] - (
            x[1] - x[0]) / figsize[0] * figsize[1] * 0.33
    y_coord = y[1] - (y[1] - y[0]) * 0.35
    ax2.text(x_coord, y_coord, str(data.describe()),
             rotation=0,
             fontsize=figsize[1] * 1.2,
             bbox={'facecolor': 'white', 'boxstyle': 'round', 'pad': 1, 'alpha': 0.8}
             )
    plt.show()
    if not (fdist is None):
        horizont = f'{text.RED}{"-" * int(len(texts[3][lang]) * 0.75)}{text.END}'
        print(horizont)
        print(f'{texts[2][lang]} {text.BG_SILVER}{text.BOLD} {alpha_fact:.2%} {text.END} {texts[3][lang]}')
        print(horizont)


def date_hist_describe(df, col, xlabel=None, data=None, bins=100,
                       subtitle='', figsize=(12, 6), fontsize_label=None, fontsize_title=None, lang=None, **kwargs):
    """Histogram with a boxplot for a time series

Parameters
----------
df: pandas.DataFrame
    Input data table

col: str
    Name of the column with the feature under consideration

xlabel: str, default=None
    X-Axis Label

data: pandas.Series, default=None
    Table of input data in case you need to consider data not from df

bins: int, default=100
    Number of histogram bins to be used

subtitle: str, default=''
    Additional text in the title of the graph

figsize: 2-tuple of floats, default=(12, 6)
    Figure dimension (width, height) in inches.

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

**kwargs:
    Properties, optional

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Distribution of the count of values on the timeline',
         'RU': 'Распределение количества значений по временной шкале'},
        {'EN': 'Count of values', 'RU': 'Кол-во значений'},
        {'EN': 'General information on the date scale', 'RU': 'Общая информация по шкале дат'},
        {'EN': 'The data is arranged in chronological order', 'RU': 'Данные упорядочены в хронологическом порядке'},
        {'EN': 'Dates are not ordered', 'RU': 'Даты не упорядочены'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    if data is None:
        data = df[col]
    if xlabel is None:
        try:
            xlabel = description[col]
        except:
            pass

    plt.figure(figsize=figsize)
    data.hist(bins=bins, **kwargs)

    plt.title(f'{texts[0][lang]}\n({xlabel}){subtitle}', pad=15, fontsize=fontsize_title)
    plt.xlabel(xlabel, fontsize=fontsize_label)
    plt.ylabel(texts[1][lang], fontsize=fontsize_label)

    plt.show()
    print(f'{text.BOLD}{text.BG_SILVER} {texts[2][lang]}: ', text.END)
    display(data.describe())

    print(text.BOLD, text.BG_SILVER)
    if data.is_monotonic_increasing:
        print(texts[3][lang])
    else:
        print(texts[4][lang])
    print(text.END)


def u_hist_box_describe(data, xlabel, *, bins=50, describe=True,
                        subtitle='', figsize=(10, 10), fontsize_label=None, fontsize_title=None, lang=None, **kwargs):
    """Multilayer histogram with boxplotм

Parameters
----------
data: pandas.DataFrame
    Input data table

xlabel: str
    X-Axis Label

bins: int, default=50
    Number of histogram bins to be used

describe: bool, default=True
    Display statistical information on a graph

subtitle: str, default=''
    Additional text in the title of the graph

figsize: 2-tuple of floats, default=(10, 10)
    Figure dimension (width, height) in inches.

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

**kwargs:
    Properties, optional

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Count of values', 'RU': 'Количество значений'},
        {'EN': 'Distribution for parameter', 'RU': 'Распределение показателя'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    fig = plt.figure()

    count = len(data.columns)

    # Разделение fig на зоны разных размеров:
    gs1 = GridSpec(7 + count, 1, left=0.05, right=0.95, hspace=0.03)
    # (y, x) - размеры сетки (высота, ширина)
    # left - расположение левой границы всей сетки (топа margin)
    # right - расположение правой границы всей сетки (топа margin)
    # wspace, hspace - зазоры между графиками (вертикальный, горизонтальный)
    ax = [''] * (count + 1)
    ax[count] = fig.add_subplot(gs1[count:, :])
    for i in range(count):
        ax[i] = fig.add_subplot(gs1[i:i + 1, :], sharex=ax[-1])

    # Plotting:
    color = ['darkcyan', 'darkorchid', 'gold', 'firebrick', 'royalblue']
    color_back = [(0 / 255, 139 / 255, 139 / 255, 0.2),
                  (153 / 255, 50 / 255, 204 / 255, 0.2),
                  (255 / 255, 215 / 255, 0 / 255, 0.2),
                  (178 / 255, 34 / 255, 34 / 255, 0.2),
                  (65 / 255, 105 / 255, 225 / 255, 0.2)]
    # а больше пяти нецелесообразно, будет сливаться все
    i = 0
    for col in data.columns:
        data[col].plot(ax=ax[i], kind='box', vert=False, widths=0.8, color='black')
        data[col].plot(ax=ax[-1], kind='hist', bins=bins, histtype='step', linewidth=2, alpha=0.6 + 0.4 / count,
                       color=color[i], **kwargs)
        data[col].plot(ax=ax[-1], kind='hist', bins=bins, alpha=1 / 2 / count, color=color[i], label='', **kwargs)
        ax[i].set_facecolor(color_back[i])
        i += 1

    # Various chart settings:
    fig.set_figwidth(figsize[0])
    fig.set_figheight(figsize[1])

    ax[0].xaxis.tick_top()
    ax[-1].minorticks_on()
    ax[-1].grid(which='major',
                color='darkgrey',
                linewidth=1.2)
    ax[-1].grid(which='minor',
                color='darkgrey',
                linestyle=':')

    for i in range(count):
        ax[i].xaxis.tick_top()
        ax[i].tick_params(labelsize=6)
        ax[i].set_yticklabels([''])
    ax[-1].set_xlabel(xlabel, fontsize=fontsize_label)
    ax[-1].set_ylabel(texts[0][lang], fontsize=fontsize_label)
    ax[0].tick_params(labelsize=12)
    ax[-1].tick_params(labelsize=12)
    ax[0].set_title(f'{texts[1][lang]} "{xlabel}"{subtitle}', pad=15, fontsize=fontsize_title)
    ax[-1].legend(fontsize=fontsize_label, loc='upper right')

    if describe:
        describe_data = data.describe().drop(['25%', '75%'])
        bit = 5 - len(str(round(data.mean()[0] // 1)))
        x = ax[-1].get_xbound()
        y = ax[-1].get_ybound()
        ax[-1].set_ylim(y[0], y[1] * 1.3)
        x_coord = x[0] + (x[1] - x[0]) / figsize[0] * figsize[1] * 0.03
        y_coord = y[1] - (y[1] - y[0]) * 0
        ax[-1].text(x_coord, y_coord, str(describe_data.round(bit)),
                    rotation=0,
                    fontsize=figsize[1] * 1.0,
                    bbox={'facecolor': (0.95, 0.95, 0.95, 0.9), 'boxstyle': 'round', 'pad': 0.6}
                    )


def print_scatter(df, x, y,
                  subtitle='', figsize=(8, 8), fontsize_label=None, fontsize_title=None, lang=None, **kwargs):
    """Drawing a scatter plot

Parameters
----------
df: pandas.DataFrame
    Input data table

x, y: keys in df
    Variables that specify positions on the x and y axes. 

subtitle: str, default=''
    Additional text in the title of the graph

figsize: 2-tuple of floats, default=(8, 8)
    Figure dimension (width, height) in inches.

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

**kwargs:
    Properties, optional

Returns
-------
graph: None
    A graph is being built
"""
    xlabel = description.get(x, x)
    ylabel = description.get(y, y)

    texts = [
        {'EN': 'Scatter plot with linear regression', 'RU': 'Диаграмма рассеяния с линейной регрессией'},
        {'EN': 'Correlation', 'RU': 'Корреляция'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG

    plt.figure(figsize=figsize)

    alpha = (1 - k) ** 2 if (k := math.log10(len(df[x])) / 10) >= 0.1 else 1
    sns.scatterplot(data=df, x=x, y=y, alpha=alpha, **kwargs)

    xs = [df[x].min(), df[x].max()]
    a = df[x].cov(df[y], ddof=0) / df[x].var(ddof=0)
    b = df[y].mean() - a * df[x].mean()
    plt.plot(xs, list(map(lambda r: a * r + b, xs)), ',-', color='tomato', linewidth=3, markersize=12)

    plt.grid(which='major',
             color='grey',
             linestyle=':')
    plt.tick_params(labelsize=12)
    plt.title(f'{texts[0][lang]}:\n{ylabel} = f ( {xlabel} ){subtitle}', pad=15, fontsize=fontsize_title)
    plt.xlabel(xlabel, fontsize=fontsize_label)
    plt.ylabel(ylabel, fontsize=fontsize_label)

    plt.text(df.dropna()[x].max() * 0.4, df.dropna()[y].max() * 0.9, f'{texts[1][lang]}:\n{df[x].corr(df[y]):.4f}',
             rotation=0,
             fontsize=14,
             bbox={'facecolor': 'white', 'boxstyle': 'round', 'pad': 0.75, 'alpha': 0.5},
             )

    plt.show()


def print_corr(df, figsize=None, fontsize_title=None, lang=None, **kwargs):
    """Feature correlation graph

Parameters
----------
df: pandas.DataFrame
    Input data table

figsize: 2-tuple of floats, default=(8, 8)
    Figure dimension (width, height) in inches.

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

**kwargs:
    Properties, optional

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Correlation of features', 'RU': 'Корреляция признаков'},
        {'EN': 'Maximum detected correlation', 'RU': 'Максимальная выявленная корреляция'},
    ]
    if figsize is None:
        fig_side = df.select_dtypes(include='number').shape[1]
        figsize = (fig_side, fig_side * 0.6)
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    plt.figure(figsize=figsize)
    sns.heatmap(df.corr(numeric_only=True), annot=True, fmt='.2f', cmap='YlGnBu', **kwargs)
    plt.title(texts[0][lang], pad=15, fontsize=fontsize_title)
    plt.show()
    print(f'{texts[1][lang]}: \
{text.BOLD}{text.BG_SILVER} {df.corr(numeric_only=True).replace(1, 0).abs().max().max():.3f} {text.END}')


def target_corr_binary(df, col, target, as_category=False, bins=50, ylabel=None,
                       subtitle='', figsize=(7, 7), fontsize_label=None, fontsize_title=None, lang=None, **kwargs):
    """Зависимость признака от целевого бинарного признака

Parameters
----------
df: pandas.DataFrame
    Input data table

col: str
    Name of the column with the feature under consideration

target: str
    The name of the column with the target feature

as_category: bool, default=False
    The feature in question is categorical

bins: int, default=50
    Number of histogram bins to be used

ylabel: str, default=None
    Y-Axis Label

subtitle: str, default=''
    Additional text in the title of the graph

figsize: 2-tuple of floats, default=(7, 7)
    Figure dimension (width, height) in inches.

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

**kwargs:
    Properties, optional

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Distribution of the parameter', 'RU': 'Распределение показателя'},
        {'EN': 'depending on the target', 'RU': 'в зависимости от целевого признака'},
        {'EN': 'Count of values', 'RU': 'Кол-во значений'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    df_in = df[[col, target]].copy()
    if as_category:
        df_in[col] = df_in[col].astype('str')

    if ylabel is None:
        try:
            ylabel = description[col]
        except:
            pass

    fig, axs = plt.subplots(1, 2, sharey=True)
    plt.subplots_adjust(wspace=0, hspace=1)
    fig.set_figwidth(figsize[0])
    fig.set_figheight(figsize[1])
    fig.suptitle(f'{texts[0][lang]} "{ylabel}"{subtitle}\n {texts[1][lang]}', fontsize=fontsize_title)

    sns.histplot(ax=axs[0], data=df_in.query(f'{target}==0'), y=col, bins=bins, color='tab:blue', label=f'{target} 0',
                 **kwargs)  # element='step'
    sns.histplot(ax=axs[1], data=df_in.query(f'{target}==1'), y=col, bins=bins, color='tab:orange', label=f'{target} 1',
                 **kwargs)  # element='step'

    x_max = max([axs[0].get_xbound()[1], axs[1].get_xbound()[1]])
    y_min, y_max = axs[0].get_ybound()
    axs[0].axis([x_max, 0, y_min, y_max])
    axs[1].axis([0, x_max, y_min, y_max])

    for ax in axs:
        ax.grid(color='grey', linestyle=':')
        ax.spines['top'].set_visible(False)
        ax.set_xlabel(texts[2][lang], fontsize=fontsize_label)
        ax.tick_params(labelsize=12)
        ax.legend(fontsize=13, loc='best')
    axs[0].set_ylabel(ylabel, fontsize=fontsize_label)
    axs[1].spines['right'].set_visible(False)

    plt.show()


def target_corr_reg(df, col, target, as_category=False, xlabel=None, ylabel=None,
                    subtitle='', figsize=(8, 8), fontsize_label=None, fontsize_title=None, lang=None, **kwargs):
    """Dependence of the feature on the target regressive feature

Parameters
----------
df: pandas.DataFrame
    Input data table

col: str
    Name of the column with the feature under consideration

target: str
    The name of the column with the target feature

as_category: bool, default=False
    The feature in question is categorical

xlabel: str, default=None
    X-Axis Label (target feature)

ylabel: str, default=None
    Y-Axis Label

subtitle: str, default=''
    Additional text in the title of the graph

figsize: 2-tuple of floats, default=(8, 8)
    Figure dimension (width, height) in inches.

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

**kwargs:
    Properties, optional

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Distribution of the parameter', 'RU': 'Распределение показателя'},
        {'EN': 'depending on the target', 'RU': 'в зависимости от целевого признака'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    df_in = df[[col, target]].copy()
    if as_category:
        df_in[col] = df_in[col].astype('str')

    if ylabel is None:
        try:
            ylabel = description[col]
            xlabel = description[target]
        except:
            pass

    if df_in[col].nunique() < 8 and figsize[1] == 8:
        figsize = (figsize[0], df_in[col].nunique())

    plt.figure(figsize=figsize)
    plt.grid(visible=True, axis='both', color='grey', linestyle=':')

    sns.histplot(data=df_in, x=target, y=col, **kwargs)

    plt.title(f'{texts[0][lang]} "{ylabel}"{subtitle}\n {texts[1][lang]}', pad=15, fontsize=fontsize_title)
    plt.xlabel(xlabel, fontsize=fontsize_label)
    plt.ylabel(ylabel, fontsize=fontsize_label)
    plt.tick_params(labelsize=12)

    plt.show()


def gaussian_distribution(data, required_score, name='some values',
                          fontsize_label=None, fontsize_title=None, lang=None, figsize=(10, 8)):
    """Normal distribution and probability of loss is less than `required_score`

Parameters
----------
data: pandas.DataFrame or numpy.array
    Variation series

required_score: numeric
    The threshold value in question

name: str, default='some values'
    Name of the parameter under consideration

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

figsize: 2-tuple of floats, default=(10, 8)
    Figure dimension (width, height) in inches.

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Normal \ndistribution', 'RU': 'Нормальное \nраспределение'},
        {'EN': 'Probabilities', 'RU': 'Вероятности'},
        {'EN': 'Desired \nvalue', 'RU': 'Искомое \nзначение'},
        {'EN': 'Values for', 'RU': 'Значения для'},
        {'EN': 'Frequency for normal distribution', 'RU': 'Частота для нормального распределения'},
        {'EN': 'Probability of value greater than given', 'RU': 'Вероятность значения больше данного'},
        {'EN': 'Normal distribution', 'RU': 'Нормальное распределение'},
        {'EN': 'set of', 'RU': 'набор из'},
        {'EN': 'values', 'RU': 'значений'},
        {'EN': 'The probability\nless than needed', 'RU': 'Вероятность меньше\nискомого'},
        {'EN': 'Average', 'RU': 'Среднее'},
        {'EN': 'Rejection', 'RU': 'Отклонение'},
        {'EN': 'The probability of getting a value is less', 'RU': 'Вероятность получить значение меньше'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    # Normal distribution
    mu = data.mean()
    sigma = np.std(data, ddof=1)

    x = [i / 1000 for i in range(int((mu - 4 * sigma) * 1000), int((mu + 4 * sigma) * 1000))]
    distr = st.norm(mu, sigma)

    # Plotting
    fig, ax1 = plt.subplots()
    ax2 = ax1.twinx()
    ax1.plot(x, distr.pdf(x), label=texts[0][lang], color='r', linewidth=4)
    ax2.plot(x, distr.cdf(x), label=texts[1][lang], color='b', linestyle='--', linewidth=2)
    ax2.plot([required_score, required_score], [0, 1], label=texts[2][lang], linestyle=':', color='g', linewidth=4)

    fig.set_figwidth(figsize[0])
    fig.set_figheight(figsize[1])

    ax1.minorticks_on()
    ax1.grid(which='major',
             color='grey',
             linewidth=1.2)
    ax1.grid(which='minor',
             color='grey',
             linestyle=':')

    ax1.legend(fontsize=12, loc='center left')
    ax2.legend(fontsize=12, loc='center right')

    ax1.set_xlabel(f'{texts[3][lang]} {name}', fontsize=fontsize_label)
    ax1.set_ylabel(texts[4][lang], fontsize=fontsize_label)
    ax2.set_ylabel(texts[5][lang], fontsize=fontsize_label)
    ax1.tick_params(labelsize=12)
    ax2.tick_params(labelsize=12)
    ax1.set_title(f'{texts[6][lang]} {name}\n({texts[7][lang]} {data.shape[0]} {texts[8][lang]})', pad=15,
                  fontsize=fontsize_title)

    ax2.text(mu - 4 * sigma, 0.85, f'{texts[9][lang]} {required_score}:\n{distr.cdf(required_score):.3%}',
             rotation=0,
             fontsize=min(figsize) * 1.75,
             bbox={'facecolor': 'white', 'pad': min(figsize)}
             )
    ax2.text(mu - 4 * sigma, 0.3, f'{texts[10][lang]} = {mu:.4f}\n{texts[11][lang]} = {sigma:.4f}',
             rotation=0,
             fontsize=min(figsize) * 1.5,
             bbox={'facecolor': 'white', 'pad': min(figsize)}
             )
    plt.show()
    print('-' * options.TABLE_SIZE)
    print(f'\x1b[1m{texts[12][lang]} {required_score} = \x1b[43m {distr.cdf(required_score):.3%} \x1b[49m\x1b[22m')
    print('-' * options.TABLE_SIZE)
    print()
