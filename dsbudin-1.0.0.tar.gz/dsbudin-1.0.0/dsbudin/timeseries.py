import pandas as pd
import numpy as np
from statsmodels.tsa.seasonal import seasonal_decompose
from scipy import stats as st
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import get_scorer


class Options:
    """Module settings:

Attributes
----------
FONTSIZE_LABEL = 14
    Font size for axis labels

FONTSIZE_TITLE = 16
    Font size for graph names

LANG = 'EN'
    The language of the output text: 'RU' or 'EN'
    """
    FONTSIZE_LABEL = 14
    FONTSIZE_TITLE = 16
    LANG = 'EN'

    def __repr__(self):
        return f'FONTSIZE_LABEL = {self.FONTSIZE_LABEL}\n\
FONTSIZE_TITLE = {self.FONTSIZE_TITLE}\n\
LANG = {self.LANG}\n\
'


options = Options()


def trend_season(df, resampling='1D', subtitle=None, fontsize_label=None, fontsize_title=None, lang=None):
    """Drawing trends and seasonality on a chart for time series

Parameters
----------
df: pandas.DataFrame
    Input data table

resampling: str, default='1D'
    The offset string or object representing target conversion

subtitle: str, default=resampling
    Additional text in the title of the graph

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Seasonality', 'RU': 'Сезонность'},
        {'EN': 'Trend', 'RU': 'Тренд'},
        {'EN': 'Trends and seasonality', 'RU': 'Тренды и сезонность'},
        {'EN': 'Timeline', 'RU': 'Временная шкала'},
        {'EN': 'Values', 'RU': 'Значения'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    decomposed = seasonal_decompose(df.resample(resampling).sum())
    if subtitle is None:
        subtitle = resampling

    fig, ax1 = plt.subplots()
    ax2 = ax1.twinx()

    fig.set_figwidth(15)
    fig.set_figheight(5)

    decomposed.seasonal.plot(ax=ax1, linewidth=1.5, color='firebrick', label=texts[0][lang])
    decomposed.trend.plot(ax=ax2, linewidth=1, color='darkcyan', alpha=0.8, label=texts[1][lang])
    ax2.fill_between(decomposed.trend.index, decomposed.trend, decomposed.trend.min(), color='darkcyan', alpha=0.15)

    ax1.set_ylim([decomposed.seasonal.min() * 1.6, decomposed.seasonal.max() * 1.6])

    ax1.grid(visible=True, axis='x')
    ax1.grid(which='major',
             color='grey',
             axis='x',
             linewidth=1.2)
    ax1.grid(which='minor',
             color='grey',
             linestyle=':')
    ax1.spines['top'].set_visible(False)
    ax2.spines['top'].set_visible(False)
    ax2.margins(0, 0)

    ax1.tick_params(labelsize=12)
    ax2.tick_params(labelsize=12)
    ax1.set_title(f'{texts[2][lang]} ({subtitle})', pad=20, fontsize=fontsize_title)
    ax1.set_xlabel(texts[3][lang], fontsize=fontsize_label)
    ax1.set_ylabel(texts[4][lang], fontsize=fontsize_label)
    ax2.set_ylabel(texts[4][lang], fontsize=fontsize_label)
    ax1.legend(fontsize=fontsize_label, loc='upper center', facecolor='mistyrose', framealpha=1)
    ax2.legend(fontsize=fontsize_label, loc='lower center', facecolor='lightcyan', framealpha=1)


def research_test_split(df, test_size=0.2, random_state=None, lang=None):
    """Breakdown into validation and test samples for time series

Parameters
----------
df: pandas.DataFrame
    Input data table

test_size: float, default=0.2
    Test sample size

random_state: int, RandomState instance, default=None
    Controls the randomness

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

Returns
-------
splitting: list, length=2 * len(arrays)
    List containing train-test split of inputs.
"""
    texts = [
        {'EN': 'Sample', 'RU': 'Выборка'},
        {'EN': 'Research', 'RU': 'Исследовательская'},
        {'EN': 'Test', 'RU': 'Тестовая'},
        {'EN': 'Start', 'RU': 'Начало'},
        {'EN': 'End', 'RU': 'Конец'},
        {'EN': 'Count of values', 'RU': 'Количество значений'},
        {'EN': 'Sample share', 'RU': 'Доля выборки'},
    ]
    if lang is None:
        lang = options.LANG
    
    df_research, df_test = train_test_split(df, test_size=test_size, random_state=random_state, shuffle=False)
    print()
    display(pd.DataFrame({
        texts[0][lang]: [texts[1][lang], texts[2][lang]],
        texts[3][lang]: [df_research.index.min(), df_test.index.min()],
        texts[4][lang]: [df_research.index.max(), df_test.index.max()],
        texts[5][lang]: [df_research.shape[0], df_test.shape[0]],
        texts[6][lang]: [df_research.shape[0] / df.shape[0], df_test.shape[0] / df.shape[0]],
    }).style.format({texts[5][lang]: '{:.0f}', texts[6][lang]: '{:.2%}'})
            )
    return df_research, df_test


def cross_val_score(estimator, x, y, *, scoring, cv=5):
    """Cross Validation for Time Series.
Trained each time on a set equal to TRAIN_PERIOD. Validated by `cv` size.
Due to the function adjustment to the standard form (for use in other functions)
I can't add TRAIN_PERIOD as another parameter, so I took the global variable (which, I understand, is not good)

You can use a regular cross_val_score using:
    sklearn.model_selection.TimeSeriesSplit(n_splits=5, *, max_train_size = TRAIN_PERIOD, test_size=None, gap=0)

Parameters
----------
estimator: estimator object implementing ‘fit’
    The object to use to fit the data.

x: array-like of shape (n_samples, n_features)
    The data to fit. Can be for example a list, or an array.

y: array-like of shape (n_samples,) or (n_samples, n_outputs)
    The target variable to try to predict.

scoring: str or callable
    A str (https://scikit-learn.org/stable/modules/model_evaluation.html)
    or a scorer callable object / function with signature scorer(estimator, X, y)
    which should return only a single value.

cv: int, default=5
    Determines the cross-validation splitting strategy.

Returns
-------
ndarray of float of shape=(len(list(cv)),)
    Array of scores of the estimator for each run of the cross validation.
"""
    res = []
    step = (len(x) - TRAIN_PERIOD) // cv
    for i in range(cv):
        index_start = i * step
        index_end = index_start + TRAIN_PERIOD

        x_train = x.iloc[index_start:index_end]  # обучающая = длине TRAIN_PERIOD
        x_valid = x.iloc[index_end:index_end + step]  # валидная = (длина(X) - TRAIN_PERIOD) / cv
        y_train = y[x_train.index]
        y_valid = y[x_valid.index]

        estimator.fit(x_train, y_train)
        scorer = get_scorer(scoring)

        res.append(scorer(estimator, x_valid, y_valid))
    return np.array(res)


# ----------------------------------------------------------------------------------
# Analysis of results

def predictions_fact(y_true, predictions, subtitle='', figsize=(15, 5),
                     fontsize_label=None, fontsize_title=None, lang=None):
    """Comparison of fact and prediction for time series on a graph

Parameters
----------
y_true: array-like
    Actual values of the feature under consideration

predictions: array-like
    Predicted values of the feature under consideration

subtitle: str, default=''
    Additional text in the title of the graph

figsize: 2-tuple of floats, default=(15,5)
    Figure dimension (width, height) in inches.

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'True values', 'RU': 'Фактические данные'},
        {'EN': 'Predictions', 'RU': 'Предсказания'},
        {'EN': 'Difference', 'RU': 'Разница'},
        {'EN': 'Fact/prediction graph', 'RU': 'График факта/предсказаний'},
        {'EN': 'Timeline', 'RU': 'Временная шкала'},
        {'EN': 'Values', 'RU': 'Значения'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    plt.figure(figsize=figsize)
    plt.grid(visible=True, axis='both')

    plt.grid(visible=True, axis='x')
    plt.grid(which='major',
             color='grey',
             axis='x',
             linewidth=1.2)
    plt.grid(which='minor',
             color='grey',
             linestyle=':')

    y_true.plot(linewidth=1.5, color='darkblue', label=texts[0][lang])
    predictions.plot(linewidth=1.5, color='darkcyan', alpha=0.8, label=texts[1][lang])
    plt.fill_between(y_true.index, y_true, predictions, color='salmon', alpha=0.2, label=texts[2][lang])
    plt.fill_between(y_true.index, y_true - predictions, np.zeros(y_true.shape[0]), color='salmon', alpha=0.4)

    plt.tick_params(labelsize=12)

    plt.title(f'{texts[3][lang]} {subtitle}', pad=15, fontsize=fontsize_title)
    plt.xlabel(texts[4][lang], fontsize=fontsize_label)
    plt.ylabel(texts[5][lang], fontsize=fontsize_label)
    plt.legend(fontsize=fontsize_label, loc='upper center')


def predictions_remains(y_true, predictions, figsize=(12, 12),
                        fontsize_label=None, fontsize_title=None, lang=None):
    """Analysis of remains for time series predictions

Parameters
----------
y_true: array-like
    Actual values of the feature under consideration

predictions: array-like
    Predicted values of the feature under consideration

figsize: 2-tuple of floats, default=(12, 12)
    Figure dimension (width, height) in inches.

fontsize_label: int, default=options.FONTSIZE_LABEL
    Font size for axis labels

fontsize_title: int, default=options.FONTSIZE_TITLE
    Font size for graph names

lang: str, default=options.LANG
    The language of the output text: 'RU' or 'EN'

Returns
-------
graph: None
    A graph is being built
"""
    texts = [
        {'EN': 'Normal \ndistribution', 'RU': 'Нормальное \nраспределение'},
        {'EN': 'Normal distribution', 'RU': 'Нормальное распределение'},
        {'EN': 'Difference fact/prediction', 'RU': 'Разница факт/предсказание'},
        {'EN': 'Count of values', 'RU': 'Количество значений'},
        {'EN': 'Error spread', 'RU': 'Разброс ошибок'},
        {'EN': 'Prediction values', 'RU': 'Значения предсказаний'},
        {'EN': 'Correlation', 'RU': 'Корреляция'},
        {'EN': 'Autocorrelation of offsets', 'RU': 'Автокорреляция остатков'},
        {'EN': 'Timeline', 'RU': 'Временная шкала'},
    ]
    if fontsize_label is None:
        fontsize_label = options.FONTSIZE_LABEL
    if fontsize_title is None:
        fontsize_title = options.FONTSIZE_TITLE
    if lang is None:
        lang = options.LANG
    
    remains = y_true - predictions

    mu = remains.mean()
    sigma = np.std(remains, ddof=1)
    sigma_width = 4

    x = [i for i in range(int(mu - sigma_width * sigma), int(mu + sigma_width * sigma))]
    distr = st.norm(mu, sigma)

    bins = 100
    plt.figure(figsize=(figsize[0] / 2, figsize[1] / 3))
    remains.plot(kind='hist', bins=bins, histtype='step', linewidth=0.5, color='darkslategrey')
    remains.plot(kind='hist', bins=bins, color='darkcyan', alpha=0.5)
    plt.plot(x, distr.pdf(x) * remains.shape[0] * int(sigma_width * 2 * sigma) / bins, label=texts[0][lang],
             color='firebrick', linewidth=1.5, linestyle='--')

    plt.title(texts[1][lang], pad=15, fontsize=fontsize_title)
    plt.xlabel(texts[2][lang], fontsize=fontsize_label)
    plt.ylabel(texts[3][lang], fontsize=fontsize_label)

    plt.show()

    plt.figure(figsize=(figsize[0] / 2, figsize[1] / 3))
    plt.scatter(predictions, remains, s=30, color='darkcyan', alpha=0.3)
    plt.title(texts[4][lang], pad=15, fontsize=fontsize_title)
    plt.xlabel(texts[5][lang], fontsize=fontsize_label)
    plt.ylabel(texts[2][lang], fontsize=fontsize_label)
    plt.text(predictions.min() * 1.01, remains.max() - (remains.max() - remains.min()) * 0.15,
             f'{texts[6][lang]}:\n{predictions.corr(remains):.4f}',
             rotation=0,
             fontsize=fontsize_label)

    plt.show()

    plt.figure(figsize=(figsize[0], figsize[1] / 3))
    remains.plot(kind='bar', width=1, color='darkcyan')
    plt.plot([0, remains.shape[0]], [0, 0], linewidth=1.1, color='firebrick')
    plt.title(texts[7][lang], pad=15, fontsize=fontsize_title)
    plt.xlabel(texts[8][lang], fontsize=fontsize_label)
    plt.ylabel(texts[2][lang], fontsize=fontsize_label)
    plt.xticks([])

    plt.show()
