import pandas as pd
import numpy as np

from sklearn.metrics import r2_score


def kramer(x, y):
    """Solution of the system according to Kramer 's formulas

Parameters
----------
x: array-like
    Factor feature

y: array-like
    Factor feature

Returns
-------
a, b: float
    Coefficients of the linear equation y = ax + b
"""
    x_data = np.array(x)
    y_data = np.array(y)
    sum_x = sum(x_data)
    sum_x2 = np.dot(x_data, x_data)
    n = len(x_data)
    sum_y = sum(y_data)
    sum_xy = np.dot(x_data, y_data)

    det_main = np.linalg.det([[sum_x2, sum_x], [sum_x, n]])
    det_a = np.linalg.det([[sum_xy, sum_y], [sum_x, n]])
    det_b = np.linalg.det([[sum_x2, sum_x], [sum_xy, sum_y]])

    a = det_a / det_main
    b = det_b / det_main
    return a, b


def get_reg_lin(x, y):
    """Obtaining a linear regression equation
    y = a * x + b

Parameters
----------
x: array-like
    Factor feature

y: array-like
    Factor feature

Returns
-------
f: str
    Linear regression expression

a: float
    Coefficient of the linear regression equation

b: float
    Coefficient of the linear regression equation
"""
    a, b = kramer(x, y)
    f = f'{a:.5g} * x + {b:.5g}'
    return f, a, b


def get_reg_exp(x, y):
    """Obtaining an exponential regression equation
    y = b * e ** (a * x)

Parameters
----------
x: array-like
    Factor feature

y: array-like
    Factor feature

Returns
-------
f: str
    Exponential regression expression

a: float
    Coefficient of the exponential regression equation

b: float
    Coefficient of the exponential regression equation
"""
    x = np.array(x)
    y = np.array(y)
    if any(y <= 0):
        return 'np.nan', None, None
    a, B = kramer(x, np.log(y))
    b = np.exp(B)
    f = f'{b:.5g} * np.exp({a:.5g} * x)'
    return f, a, b


def get_reg_pow(x, y):
    """Obtaining a power regression equation
    y = b * x ** a

Parameters
----------
x: array-like
    Factor feature

y: array-like
    Factor feature

Returns
-------
f: str
    Power regression expression

a: float
    Coefficient of the power regression equation

b: float
    Coefficient of the power regression equation
"""
    x = np.array(x)
    y = np.array(y)
    if any(x <= 0) or any(y <= 0):
        return 'np.nan', None, None
    a, B = kramer(np.log(x), np.log(y))
    b = np.exp(B)
    f = f'{b:.5g} * x ** {a:.5g}'
    return f, a, b


def get_reg_log(x, y):
    """Obtaining a logarithmic regression equation
    y = a * ln(x) + b

Parameters
----------
x: array-like
    Factor feature

y: array-like
    Factor feature

Returns
-------
f: str
    Logarithmic regression expression

a: float
    Coefficient of the logarithmic regression equation

b: float
    Coefficient of the logarithmic regression equation
"""
    x = np.array(x)
    y = np.array(y)
    if any(x <= 0):
        return 'np.nan', None, None
    a, b = kramer(np.log(x), y)
    f = f'{a:.5g} * np.log(x) + {b:.5g}'
    return f, a, b


def get_reg_hyp(x, y):
    """Obtaining a hyperbolic regression equation
    y = a / x + b

Parameters
----------
x: array-like
    Factor feature

y: array-like
    Factor feature

Returns
-------
f: str
    Hyperbolic regression expression

a: float
    Coefficient of the hyperbolic regression equation

b: float
    Coefficient of the hyperbolic regression equation
"""
    x = np.array(x)
    y = np.array(y)
    if any(x == 0):
        return 'np.nan', None, None
    a, b = kramer(1/x, y)
    f = f'{a:.5g} / x + {b:.5g}'
    return f, a, b


def make_function(expression):
    """Converting an equation expression containing x into a python function

Parameters
----------
expression: str
    Equation expression containing x,  like '-71.661 * np.log(x) + 251.08'

Returns
-------
func: python functions
    The function of calculating y by x
"""
    def func(x):
        x = np.array(x)
        return eval(expression)
    return func


def get_reg_results(x, y):
    """Comparison of various regressions

Parameters
----------
x: array-like
    Factor feature

y: array-like
    Factor feature

Returns
-------
df_res: pandas.DataFrame
    The resulting table with determination indices and regression equations
"""
    x = np.array(x)
    y = np.array(y)
    results = []
    functions = {'linear': get_reg_lin,
                 'exponential': get_reg_exp,
                 'power': get_reg_pow,
                 'logarithmic': get_reg_log,
                 'hyperbolic': get_reg_hyp,
                 }
    for name, get_reg in functions.items():
        try:
            f = get_reg(x, y)[0]
        except:
            continue
        else:
            if f == 'np.nan':
                continue
            results.append([name, r2_score(y, make_function(f)(x)), f])
            # print(f)
    return pd.DataFrame(results, columns=['name', 'R2', 'function'])
