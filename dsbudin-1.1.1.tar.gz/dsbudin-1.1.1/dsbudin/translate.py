from translate import Translator
from langdetect import detect


def translate(s: str):
    """Russian to English or English to Russian text translation

Parameters
----------
s: str
    Russian or English text

Returns
-------
trans: str
    English or Russian translation depending on the text at the input
    """
    langs = ['ru', 'en']
    from_l = detect(str(s))
    if from_l in langs:
        langs.remove(from_l)
        to_l = langs[0]
    else:
        from_l = 'en'
        to_l = 'ru'
    return Translator(from_lang=from_l, to_lang=to_l).translate(s)
